from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class NodePosition(BaseModel):
    x: float = 0
    y: float = 0


class WorkflowNode(BaseModel):
    id: str = Field(min_length=1, max_length=100)
    type: str = Field(min_length=1, max_length=100)
    position: NodePosition = Field(default_factory=NodePosition)
    params: dict[str, Any] = Field(default_factory=dict)
    collapsed: bool = False


class WorkflowEdge(BaseModel):
    id: str | None = None
    source: str = Field(min_length=1, max_length=100)
    target: str = Field(min_length=1, max_length=100)
    sourceHandle: str = "out"
    targetHandle: str = "in"


class WorkflowRequest(BaseModel):
    version: str | None = None
    image_id: str | None = None
    nodes: list[WorkflowNode] = Field(default_factory=list, max_length=500)
    edges: list[WorkflowEdge] = Field(default_factory=list, max_length=2000)
