from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.helpers import (
    ensure_bgr,
    ensure_gray,
    ensure_odd,
    kernel_from_params,
    to_float,
    to_int,
)
from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def gray_input(inputs: OperatorInputs) -> np.ndarray:
    image = inputs["in"]
    if image.ndim == 2:
        return image
    if str(inputs.get("in_color_space", "BGR")).upper() == "RGB":
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    return ensure_gray(image)

def op_read_image(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    image_path = str(params.get("image_path") or "").strip()
    if image_path:
        path = context.image_store.resolve_path(image_path)
        if path is None:
            raise ValueError(f"图片路径不存在、不可访问或不是受支持的图片：{image_path}")
    else:
        # 兼容旧版工作流中的 image_id；新前端只使用 image_path。
        image_id = params.get("image_id") or context.image_id
        if not image_id:
            raise ValueError("请在 ReadImage 节点右侧参数面板中填写图片路径")
        path = context.image_store.resolve(str(image_id))
        if path is None:
            raise ValueError(f"找不到旧版上传图片：{image_id}")

    img = context.image_store.read(path)
    if img is None:
        raise ValueError(f"OpenCV 读取图片失败：{path}")
    return {"out": img, "out_color_space": "BGR"}


def op_display(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {
        "out": inputs["in"],
        "out_color_space": inputs.get("in_color_space", "BGR"),
    }


def op_color_convert(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    image = inputs["in"]
    input_color_space = str(inputs.get("in_color_space") or ("GRAY" if image.ndim == 2 else "BGR")).upper()
    mode = str(params.get("mode", "GRAY")).strip().upper()

    if mode == "GRAY":
        if image.ndim == 2:
            output = image
        elif input_color_space == "RGB":
            output = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            output = cv2.cvtColor(ensure_bgr(image), cv2.COLOR_BGR2GRAY)
        return {"out": output, "out_color_space": "GRAY"}

    if mode == "RGB":
        if image.ndim == 2:
            output = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif input_color_space == "RGB":
            output = image.copy()
        else:
            output = cv2.cvtColor(ensure_bgr(image), cv2.COLOR_BGR2RGB)
        return {"out": output, "out_color_space": "RGB"}

    raise ValueError(f"不支持的颜色转换模式：{mode}，可选值为 GRAY 或 RGB")


def op_gray(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """旧版 Gray 节点兼容入口。"""
    return op_color_convert(inputs, {**params, "mode": "GRAY"}, context)


def op_bgr_to_rgb(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    """旧版 BGR2RGB 节点兼容入口。"""
    return op_color_convert(inputs, {**params, "mode": "RGB"}, context)

def op_invert(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.bitwise_not(inputs["in"])}

def op_normalize(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.normalize(inputs["in"], None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)}

def op_equalize_hist(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    return {"out": cv2.equalizeHist(gray)}

def op_clahe(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    clip = to_float(params.get("clip_limit", 2.0), 2.0)
    tile = max(1, to_int(params.get("tile_grid", 8), 8))
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
    return {"out": clahe.apply(gray)}

def op_mean_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.blur(inputs["in"], (ksize, ksize))}

def op_gaussian_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    sigma = to_float(params.get("sigma", 0), 0.0)
    return {"out": cv2.GaussianBlur(inputs["in"], (ksize, ksize), sigma)}

def op_median_blur(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    ksize = ensure_odd(params.get("ksize", 5), 5)
    return {"out": cv2.medianBlur(inputs["in"], ksize)}

def op_bilateral_filter(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    d = to_int(params.get("d", 7), 7)
    sigma_color = to_float(params.get("sigma_color", 75), 75)
    sigma_space = to_float(params.get("sigma_space", 75), 75)
    return {"out": cv2.bilateralFilter(inputs["in"], d, sigma_color, sigma_space)}

def op_sharpen(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    amount = to_float(params.get("amount", 1.0), 1.0)
    kernel = np.array([[0, -1, 0], [-1, 4 + amount, -1], [0, -1, 0]], dtype=np.float32)
    out = cv2.filter2D(inputs["in"], -1, kernel)
    return {"out": out}

def op_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    threshold = to_int(params.get("threshold", 127), 127)
    max_value = to_int(params.get("max_value", 255), 255)
    _, out = cv2.threshold(gray, threshold, max_value, cv2.THRESH_BINARY)
    return {"out": out}

def op_otsu_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    _, out = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return {"out": out}

def op_adaptive_threshold(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    block_size = ensure_odd(params.get("block_size", 11), 11, 3)
    c = to_int(params.get("c", 2), 2)
    out = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block_size, c)
    return {"out": out}

def op_canny(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    t1 = to_int(params.get("threshold1", 50), 50)
    t2 = to_int(params.get("threshold2", 150), 150)
    return {"out": cv2.Canny(gray, t1, t2)}

def op_sobel(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    dx = to_int(params.get("dx", 1), 1)
    dy = to_int(params.get("dy", 0), 0)
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    grad = cv2.Sobel(gray, cv2.CV_16S, dx, dy, ksize=ksize)
    return {"out": cv2.convertScaleAbs(grad)}

def op_laplacian(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    gray = gray_input(inputs)
    ksize = ensure_odd(params.get("ksize", 3), 3, 1)
    out = cv2.Laplacian(gray, cv2.CV_16S, ksize=ksize)
    return {"out": cv2.convertScaleAbs(out)}

def op_erode(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.erode(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}

def op_dilate(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    iterations = to_int(params.get("iterations", 1), 1)
    return {"out": cv2.dilate(inputs["in"], kernel_from_params(params, 3), iterations=iterations)}

def op_morph_open(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_OPEN, kernel_from_params(params, 3))}

def op_morph_close(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_CLOSE, kernel_from_params(params, 3))}

def op_morph_gradient(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    return {"out": cv2.morphologyEx(inputs["in"], cv2.MORPH_GRADIENT, kernel_from_params(params, 3))}

def op_resize(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    img = inputs["in"]
    scale = to_float(params.get("scale_percent", 50), 50.0)
    scale = max(scale, 1.0)
    width = max(1, int(img.shape[1] * scale / 100.0))
    height = max(1, int(img.shape[0] * scale / 100.0))
    return {"out": cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)}

def op_flip(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    code = to_int(params.get("flip_code", 1), 1)  # 1水平，0垂直，-1水平+垂直
    if code not in [-1, 0, 1]:
        code = 1
    return {"out": cv2.flip(inputs["in"], code)}

def op_rotate90(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    direction = to_int(params.get("direction", 0), 0)  # 0顺时针，1逆时针，2旋转180
    if direction == 1:
        code = cv2.ROTATE_90_COUNTERCLOCKWISE
    elif direction == 2:
        code = cv2.ROTATE_180
    else:
        code = cv2.ROTATE_90_CLOCKWISE
    return {"out": cv2.rotate(inputs["in"], code)}

def op_find_contours(inputs: OperatorInputs, params: OperatorParams, context: ExecutionContext) -> OperatorResult:
    img = inputs["in"]
    gray = gray_input({"in": img, "in_color_space": inputs.get("in_color_space", "BGR")})
    threshold = to_int(params.get("threshold", 127), 127)
    min_area = to_float(params.get("min_area", 20), 20.0)
    _, binary = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    canvas = ensure_bgr(img).copy()
    count = 0
    for contour in contours:
        if cv2.contourArea(contour) < min_area:
            continue
        cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
        x, y, w, h = cv2.boundingRect(contour)
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
        count += 1
    cv2.putText(canvas, f"contours: {count}", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)
    return {"out": canvas}
