from fastapi import APIRouter

from backend.api.routes import export_script, operators, upload, workflow

api_router = APIRouter()
api_router.include_router(operators.router, tags=["operators"])
api_router.include_router(upload.router, tags=["upload"])
api_router.include_router(workflow.router, tags=["workflow"])
api_router.include_router(export_script.router, tags=["export"])
