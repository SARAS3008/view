from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status

from backend.api.dependencies import get_image_store
from backend.config import MAX_UPLOAD_BYTES
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import image_to_data_url

router = APIRouter()


@router.post("/upload")
async def upload_image(
    file: UploadFile = File(...),
    image_store: ImageStore = Depends(get_image_store),
) -> dict:
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"图片不能超过 {MAX_UPLOAD_BYTES // (1024 * 1024)} MB",
        )
    if not content:
        raise HTTPException(status_code=400, detail="上传文件为空")

    try:
        stored = image_store.save(file.filename, content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "success": True,
        "image_id": stored.image_id,
        "filename": stored.original_filename,
        "preview": image_to_data_url(stored.image),
    }
