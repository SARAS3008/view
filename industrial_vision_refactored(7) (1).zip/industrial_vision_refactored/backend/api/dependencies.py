from fastapi import Request

from backend.services.image_store import ImageStore


def get_image_store(request: Request) -> ImageStore:
    return request.app.state.image_store
