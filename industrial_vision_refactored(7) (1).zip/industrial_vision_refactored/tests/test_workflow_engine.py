from pathlib import Path

import cv2
import numpy as np

from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow, topological_sort


def make_store(tmp_path: Path) -> ImageStore:
    return ImageStore(tmp_path, {".png", ".jpg", ".jpeg"})


def test_demo_workflow_executes(tmp_path: Path) -> None:
    store = make_store(tmp_path)
    ok, encoded = cv2.imencode(".png", np.full((40, 60, 3), 128, dtype=np.uint8))
    assert ok
    stored = store.save("sample.png", encoded.tobytes())

    workflow = WorkflowRequest.model_validate(
        {
            "image_id": stored.image_id,
            "nodes": [
                {"id": "n1", "type": "ReadImage"},
                {"id": "n2", "type": "Gray"},
                {"id": "n3", "type": "Canny", "params": {"threshold1": 50, "threshold2": 150}},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    assert result["success"] is True
    assert result["order"] == ["n1", "n2", "n3"]
    assert len(result["previews"]) == 3


def test_cycle_is_rejected() -> None:
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {"id": "n1", "type": "Gray"},
                {"id": "n2", "type": "Canny"},
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n1"},
            ],
        }
    )
    try:
        topological_sort(workflow.nodes, workflow.edges)
    except ValueError as exc:
        assert "存在环" in str(exc)
    else:
        raise AssertionError("应当拒绝环形流程")
