from __future__ import annotations

import csv
from pathlib import Path

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_CATALOG, OPERATOR_META
from backend.models.workflow import WorkflowRequest
from backend.services.image_store import ImageStore
from backend.services.workflow_engine import run_workflow


def write_image(path: Path, value: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image = np.full((36, 48, 3), value, dtype=np.uint8)
    cv2.rectangle(image, (8, 8), (30, 28), (255, 255, 255), -1)
    ok, buffer = cv2.imencode(path.suffix, image)
    assert ok
    buffer.tofile(str(path))


def test_custom_operator_is_auto_registered() -> None:
    assert "MeanBrightness" in OPERATORS
    assert OPERATOR_META["MeanBrightness"]["label"] == "平均亮度统计"
    custom_groups = [group for group in OPERATOR_CATALOG["图像"] if group["group"] == "自定义算子"]
    assert custom_groups
    assert "MeanBrightness" in custom_groups[0]["items"]


def test_batch_workflow_saves_images_and_csv_with_multiple_metrics(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    write_image(source_dir / "a.png", 20)
    write_image(source_dir / "nested" / "b.png", 80)

    store = ImageStore(
        upload_dir=tmp_path / "uploads",
        allowed_extensions={".png", ".jpg", ".jpeg"},
        path_base=tmp_path,
    )
    workflow = WorkflowRequest.model_validate(
        {
            "nodes": [
                {
                    "id": "n1",
                    "type": "BatchReadImages",
                    "params": {
                        "folder_path": "source",
                        "recursive": "YES",
                        "extensions": ".png",
                        "max_images": 0,
                        "continue_on_error": "YES",
                    },
                },
                {"id": "n2", "type": "MeanBrightness"},
                {"id": "n3", "type": "FindContours", "params": {"threshold": 127, "min_area": 5}},
                {
                    "id": "n4",
                    "type": "SaveBatchResults",
                    "params": {
                        "output_dir": "results",
                        "save_images": "YES",
                        "image_format": "PNG",
                        "filename_suffix": "_done",
                        "preserve_structure": "YES",
                        "write_csv": "YES",
                        "csv_filename": "measurements.csv",
                    },
                },
            ],
            "edges": [
                {"source": "n1", "target": "n2"},
                {"source": "n2", "target": "n3"},
                {"source": "n3", "target": "n4"},
            ],
        }
    )

    result = run_workflow(workflow, store)
    assert result["success"] is True
    assert result["mode"] == "batch"
    assert result["batch"]["total"] == 2
    assert result["batch"]["succeeded"] == 2
    assert result["batch"]["failed"] == 0
    assert (tmp_path / "results" / "a_done.png").is_file()
    assert (tmp_path / "results" / "nested" / "b_done.png").is_file()

    csv_path = tmp_path / "results" / "measurements.csv"
    assert csv_path.is_file()
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 2
    assert rows[0]["source_name"] == "a.png"
    assert "n2_平均亮度统计.mean_brightness" in rows[0]
    assert "n3_轮廓查找.contour_count" in rows[0]
    assert rows[0]["status"] == "success"
    assert result["previews"]
