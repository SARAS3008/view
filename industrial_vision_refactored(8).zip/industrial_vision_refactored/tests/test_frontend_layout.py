from fastapi.testclient import TestClient

from backend.main import app


client = TestClient(app)


def test_node_library_and_navigation_layout() -> None:
    response = client.get("/")
    assert response.status_code == 200

    html = response.text
    assert 'id="nodeLibraryToggle"' in html
    assert 'aria-controls="nodeLibrary"' in html
    assert 'id="nodeLibrary"' in html
    assert 'id="exportScriptButton"' in html
    assert "导出脚本" in html

    node_library = html.split('<aside id="nodeLibrary"', 1)[1].split("</aside>", 1)[0]
    assert 'id="operatorPanel"' in node_library
    assert 'id="imageInput"' not in node_library
    assert "upload-box" not in node_library
    assert "category-tabs" not in node_library

    assert 'id="imageInput"' not in html
    assert 'id="imageLightbox"' in html
    assert 'id="lightboxDownload"' in html
    assert 'id="lightboxRestore"' in html


def test_frontend_assets_include_interactive_node_preview() -> None:
    js = client.get("/assets/js/app.js")
    css = client.get("/assets/css/styles.css")

    assert js.status_code == 200
    assert css.status_code == 200
    assert "function toggleNodeLibrary()" in js.text
    assert "function downloadNodePreview(" in js.text
    assert "function openImageLightbox(" in js.text
    assert "function closeImageLightbox(" in js.text
    assert "data-preview-action=\"download\"" in js.text
    assert "data-preview-action=\"zoom\"" in js.text
    assert ".node-effect-frame img" in css.text
    assert "object-fit:contain" in css.text.replace(" ", "")
    assert ".image-lightbox.open" in css.text


def test_multiple_workflow_tabs_and_save_shortcut_are_wired() -> None:
    html = client.get("/").text
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text

    assert 'id="workflowTabs"' in html
    assert 'id="newWorkflowButton"' in html
    assert "Ctrl+S" in html
    assert "function newWorkflow()" in js
    assert "function switchWorkflow(" in js
    assert "function closeWorkflow(" in js
    assert "function renderWorkflowTabs()" in js
    assert 'event.key.toLowerCase() === "s"' in js
    assert "WORKSPACE_STORAGE_KEY" in js
    assert ".workflow-tab.active" in css
    assert ".save-state-dot.saved" in css
    assert ".save-state-dot.dirty" in css


def test_thumbnail_uses_intrinsic_size_and_batch_summary_ui_exists() -> None:
    js = client.get("/assets/js/app.js").text
    css = client.get("/assets/css/styles.css").text.replace(" ", "")
    assert ".node-effect-frameimg{display:block;width:auto;height:auto;max-width:100%;max-height:100%;object-fit:contain" in css
    assert "function renderBatchSummary(" in js
    assert "批量处理汇总" in js
