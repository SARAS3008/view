from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api.router import api_router
from backend.config import ALLOWED_IMAGE_EXTENSIONS, FRONTEND_DIR, UPLOAD_DIR
from backend.services.image_store import ImageStore


def create_app() -> FastAPI:
    application = FastAPI(
        title="Industrial Vision Workflow",
        version="2.2.0",
    )
    application.state.image_store = ImageStore(
        upload_dir=UPLOAD_DIR,
        allowed_extensions=ALLOWED_IMAGE_EXTENSIONS,
    )
    application.include_router(api_router, prefix="/api")
    application.mount(
        "/assets",
        StaticFiles(directory=FRONTEND_DIR / "assets"),
        name="assets",
    )

    @application.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "index.html")

    return application


app = create_app()
