"""自定义算子示例：计算平均亮度并把数据写入批量 CSV。"""

from __future__ import annotations

import cv2
import numpy as np

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def op_mean_brightness(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    image = inputs["in"]
    color_space = str(inputs.get("in_color_space", "BGR")).upper()
    if image.ndim == 2:
        gray = image
    elif color_space == "RGB":
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    mean_value = float(np.mean(gray))
    std_value = float(np.std(gray))
    return {
        "out": image.copy(),
        "out_color_space": color_space,
        "metrics": {
            "mean_brightness": round(mean_value, 4),
            "brightness_std": round(std_value, 4),
        },
    }


def compile_script(input_var: str, input_color: str, params: dict):
    """纯算法脚本导出扩展点。

    返回：前置语句源码列表、结果表达式源码、输出颜色空间。
    这个示例算子不改变图像，所以直接复制输入图像。
    """

    return [], f"{input_var}.copy()", input_color


OPERATOR_DEFINITION = {
    "type_name": "MeanBrightness",
    "operator": op_mean_brightness,
    "metadata": {
        "label": "平均亮度统计",
        "kind": "measure",
        "has_input": True,
        "has_output": True,
        "params": {},
        "description": "计算图像平均亮度和标准差；批量运行时自动写入 CSV。",
    },
    "category": "图像",
    "group": "自定义算子",
    "script_compiler": compile_script,
}
