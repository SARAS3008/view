"""自定义算子模板。

复制本文件并改成不以下划线开头的文件名，例如 my_operator.py；重启服务后自动加载。
"""

from __future__ import annotations

from backend.algorithms.types import ExecutionContext, OperatorInputs, OperatorParams, OperatorResult


def op_my_operator(
    inputs: OperatorInputs,
    params: OperatorParams,
    context: ExecutionContext,
) -> OperatorResult:
    image = inputs["in"]
    strength = float(params.get("strength", 1.0))

    # 在这里实现你的 OpenCV / NumPy 算法。
    output = image.copy()

    return {
        "out": output,
        "out_color_space": inputs.get("in_color_space", "BGR"),
        # metrics 会沿工作流传递，并在批量末端自动展开到 CSV。
        "metrics": {
            "strength_used": strength,
            "result_a": 0,
            "result_b": 0,
        },
    }


def compile_script(input_var: str, input_color: str, params: dict):
    """可选：支持“导出为独立算法脚本”。

    返回 (前置 Python 语句列表, 结果表达式, 输出颜色空间)。
    不需要脚本导出时，可删除本函数及下方 script_compiler 配置。
    """

    return [], f"{input_var}.copy()", input_color


OPERATOR_DEFINITION = {
    "type_name": "MyOperator",  # 全局唯一，建议使用英文 PascalCase。
    "operator": op_my_operator,
    "metadata": {
        "label": "我的算子",
        "kind": "custom",
        "has_input": True,
        "has_output": True,
        "params": {"strength": 1.0},
        "param_schema": {
            "strength": {
                "label": "处理强度",
                "type": "number",
                "help": "参数说明。",
            }
        },
        "description": "自定义算子说明。",
    },
    "category": "图像",
    "group": "自定义算子",
    "script_compiler": compile_script,
}
