from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass
from typing import Any, Callable

from backend.algorithms.types import Operator


ScriptCompiler = Callable[[str, str, dict[str, Any]], tuple[list[str], str, str]]


@dataclass(frozen=True)
class CustomOperatorDefinition:
    type_name: str
    operator: Operator
    metadata: dict[str, Any]
    category: str = "图像"
    group: str = "自定义算子"
    script_compiler: ScriptCompiler | None = None


def _definition_from_module(module: Any) -> CustomOperatorDefinition:
    raw = getattr(module, "OPERATOR_DEFINITION", None)
    if not isinstance(raw, dict):
        raise ValueError(f"{module.__name__} 必须导出 OPERATOR_DEFINITION 字典")

    type_name = str(raw.get("type_name") or "").strip()
    operator = raw.get("operator")
    metadata = raw.get("metadata")
    if not type_name:
        raise ValueError(f"{module.__name__} 缺少 type_name")
    if not callable(operator):
        raise ValueError(f"{module.__name__} 的 operator 必须可调用")
    if not isinstance(metadata, dict):
        raise ValueError(f"{module.__name__} 的 metadata 必须是字典")

    normalized_metadata = dict(metadata)
    normalized_metadata.setdefault("label", type_name)
    normalized_metadata.setdefault("category", raw.get("category", "图像"))
    normalized_metadata.setdefault("group", raw.get("group", "自定义算子"))
    normalized_metadata.setdefault("kind", "custom")
    normalized_metadata.setdefault("has_input", True)
    normalized_metadata.setdefault("has_output", True)
    normalized_metadata.setdefault("params", {})
    normalized_metadata.setdefault("description", "自定义算子")

    compiler = raw.get("script_compiler")
    if compiler is not None and not callable(compiler):
        raise ValueError(f"{module.__name__} 的 script_compiler 必须可调用")

    return CustomOperatorDefinition(
        type_name=type_name,
        operator=operator,
        metadata=normalized_metadata,
        category=str(raw.get("category") or normalized_metadata["category"]),
        group=str(raw.get("group") or normalized_metadata["group"]),
        script_compiler=compiler,
    )


def load_custom_operators() -> list[CustomOperatorDefinition]:
    """自动加载 backend/custom_operators 下的插件。

    文件名以下划线开头时会被忽略，方便保留模板或草稿。
    某个插件加载失败时抛出明确异常，避免节点库显示一个无法执行的节点。
    """

    package = importlib.import_module("backend.custom_operators")
    definitions: list[CustomOperatorDefinition] = []
    for module_info in pkgutil.iter_modules(package.__path__):
        if module_info.name.startswith("_"):
            continue
        module = importlib.import_module(f"{package.__name__}.{module_info.name}")
        definitions.append(_definition_from_module(module))
    return definitions
