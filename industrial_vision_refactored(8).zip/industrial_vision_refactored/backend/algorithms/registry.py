from __future__ import annotations

from backend.algorithms.image_ops import (
    op_adaptive_threshold,
    op_batch_read_images,
    op_bgr_to_rgb,
    op_bilateral_filter,
    op_canny,
    op_clahe,
    op_color_convert,
    op_dilate,
    op_display,
    op_equalize_hist,
    op_erode,
    op_find_contours,
    op_flip,
    op_gaussian_blur,
    op_gray,
    op_invert,
    op_laplacian,
    op_mean_blur,
    op_median_blur,
    op_morph_close,
    op_morph_gradient,
    op_morph_open,
    op_normalize,
    op_otsu_threshold,
    op_read_image,
    op_resize,
    op_rotate90,
    op_save_batch_results,
    op_sharpen,
    op_sobel,
    op_threshold,
)
from backend.algorithms.metadata import OPERATOR_CATALOG, OPERATOR_META
from backend.algorithms.plugin_loader import ScriptCompiler, load_custom_operators
from backend.algorithms.types import Operator


OPERATORS: dict[str, Operator] = {
    "ReadImage": op_read_image,
    "BatchReadImages": op_batch_read_images,
    "SaveBatchResults": op_save_batch_results,
    "Display": op_display,
    "Gray": op_gray,
    "BGR2RGB": op_bgr_to_rgb,
    "ColorConvert": op_color_convert,
    "Invert": op_invert,
    "Normalize": op_normalize,
    "EqualizeHist": op_equalize_hist,
    "CLAHE": op_clahe,
    "MeanBlur": op_mean_blur,
    "GaussianBlur": op_gaussian_blur,
    "MedianBlur": op_median_blur,
    "BilateralFilter": op_bilateral_filter,
    "Sharpen": op_sharpen,
    "Threshold": op_threshold,
    "OtsuThreshold": op_otsu_threshold,
    "AdaptiveThreshold": op_adaptive_threshold,
    "Canny": op_canny,
    "Sobel": op_sobel,
    "Laplacian": op_laplacian,
    "Erode": op_erode,
    "Dilate": op_dilate,
    "MorphOpen": op_morph_open,
    "MorphClose": op_morph_close,
    "MorphGradient": op_morph_gradient,
    "Resize": op_resize,
    "Flip": op_flip,
    "Rotate90": op_rotate90,
    "FindContours": op_find_contours,
}

CUSTOM_SCRIPT_COMPILERS: dict[str, ScriptCompiler] = {}


def _append_catalog_item(category: str, group: str, type_name: str) -> None:
    groups = OPERATOR_CATALOG.setdefault(category, [])
    target = next((item for item in groups if item.get("group") == group), None)
    if target is None:
        target = {"group": group, "items": []}
        groups.append(target)
    if type_name not in target["items"]:
        target["items"].append(type_name)


for definition in load_custom_operators():
    if definition.type_name in OPERATORS:
        raise RuntimeError(f"自定义算子名称与现有算子冲突：{definition.type_name}")
    OPERATORS[definition.type_name] = definition.operator
    OPERATOR_META[definition.type_name] = definition.metadata
    _append_catalog_item(definition.category, definition.group, definition.type_name)
    if definition.script_compiler is not None:
        CUSTOM_SCRIPT_COMPILERS[definition.type_name] = definition.script_compiler


__all__ = [
    "OPERATORS",
    "OPERATOR_META",
    "OPERATOR_CATALOG",
    "CUSTOM_SCRIPT_COMPILERS",
]
