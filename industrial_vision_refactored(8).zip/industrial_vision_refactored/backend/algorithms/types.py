from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Protocol


class ImageResolver(Protocol):
    def resolve(self, image_id: str) -> Path | None: ...
    def resolve_path(self, image_path: str) -> Path | None: ...
    def read(self, path: Path) -> Any: ...


@dataclass(frozen=True)
class ExecutionContext:
    """单次节点执行上下文。

    单图运行时 current_image_path 为空；批量运行时它指向当前正在处理的图片。
    算子不需要理解整个工作流，只读取当前图片和批次信息即可。
    """

    image_id: str | None
    image_store: ImageResolver
    current_image_path: Path | None = None
    source_root: Path | None = None
    batch_index: int = 0
    batch_total: int = 1


OperatorInputs = dict[str, Any]
OperatorParams = dict[str, Any]
OperatorResult = dict[str, Any]
Operator = Callable[[OperatorInputs, OperatorParams, ExecutionContext], OperatorResult]
