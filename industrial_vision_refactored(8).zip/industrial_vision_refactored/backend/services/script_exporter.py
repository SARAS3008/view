from __future__ import annotations

import ast
import re
from collections import defaultdict
from typing import Any

from backend.algorithms.registry import CUSTOM_SCRIPT_COMPILERS
from backend.models.workflow import WorkflowRequest
from backend.services.workflow_engine import topological_sort


def _normalize_type(node_type: str, params: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    normalized = dict(params)
    if node_type == "Gray":
        normalized["mode"] = "GRAY"
        return "ColorConvert", normalized
    if node_type == "BGR2RGB":
        normalized["mode"] = "RGB"
        return "ColorConvert", normalized
    if node_type == "BatchReadImages":
        return "ReadImage", normalized
    if node_type == "SaveBatchResults":
        return "Display", normalized
    return node_type, normalized


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"\W+", "_", value, flags=re.UNICODE).strip("_")
    if not cleaned or cleaned[0].isdigit():
        cleaned = f"node_{cleaned}"
    return cleaned


def _statement(source: str) -> ast.stmt:
    return ast.parse(source).body[0]


def _expression(source: str) -> ast.expr:
    return ast.parse(source, mode="eval").body


def _gray_expression(variable: str, color_space: str) -> str:
    if color_space == "GRAY":
        return variable
    if color_space == "RGB":
        return f"cv2.cvtColor({variable}, cv2.COLOR_RGB2GRAY)"
    return f"cv2.cvtColor({variable}, cv2.COLOR_BGR2GRAY)"


def _bgr_expression(variable: str, color_space: str) -> str:
    if color_space == "BGR":
        return variable
    if color_space == "RGB":
        return f"cv2.cvtColor({variable}, cv2.COLOR_RGB2BGR)"
    return f"cv2.cvtColor({variable}, cv2.COLOR_GRAY2BGR)"


def _odd(value: Any, default: int, minimum: int = 1) -> int:
    try:
        result = int(float(value))
    except (TypeError, ValueError):
        result = default
    result = max(minimum, result)
    return result if result % 2 else result + 1


def _integer(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _floating(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _compile_operator(
    node_type: str,
    params: dict[str, Any],
    input_var: str,
    input_color: str,
) -> tuple[list[ast.stmt], str, str]:
    """Return statements, result expression variable placeholder, and output color space."""
    statements: list[ast.stmt] = []
    output_color = input_color

    if node_type == "Display":
        expression = input_var
    elif node_type == "ColorConvert":
        mode = str(params.get("mode", "GRAY")).upper()
        if mode == "GRAY":
            expression = _gray_expression(input_var, input_color)
            output_color = "GRAY"
        elif mode == "RGB":
            if input_color == "RGB":
                expression = f"{input_var}.copy()"
            elif input_color == "GRAY":
                expression = f"cv2.cvtColor({input_var}, cv2.COLOR_GRAY2RGB)"
            else:
                expression = f"cv2.cvtColor({input_var}, cv2.COLOR_BGR2RGB)"
            output_color = "RGB"
        else:
            raise ValueError(f"不支持的颜色转换模式：{mode}")
    elif node_type == "Invert":
        expression = f"cv2.bitwise_not({input_var})"
    elif node_type == "Normalize":
        expression = f"cv2.normalize({input_var}, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)"
    elif node_type == "EqualizeHist":
        expression = f"cv2.equalizeHist({_gray_expression(input_var, input_color)})"
        output_color = "GRAY"
    elif node_type == "CLAHE":
        clip = _floating(params.get("clip_limit", 2.0), 2.0)
        tile = max(1, _integer(params.get("tile_grid", 8), 8))
        statements.append(_statement(f"clahe = cv2.createCLAHE(clipLimit={clip!r}, tileGridSize=({tile}, {tile}))"))
        expression = f"clahe.apply({_gray_expression(input_var, input_color)})"
        output_color = "GRAY"
    elif node_type == "MeanBlur":
        size = _odd(params.get("ksize", 5), 5)
        expression = f"cv2.blur({input_var}, ({size}, {size}))"
    elif node_type == "GaussianBlur":
        size = _odd(params.get("ksize", 5), 5)
        sigma = _floating(params.get("sigma", 0), 0.0)
        expression = f"cv2.GaussianBlur({input_var}, ({size}, {size}), {sigma!r})"
    elif node_type == "MedianBlur":
        size = _odd(params.get("ksize", 5), 5)
        expression = f"cv2.medianBlur({input_var}, {size})"
    elif node_type == "BilateralFilter":
        diameter = _integer(params.get("d", 7), 7)
        sigma_color = _floating(params.get("sigma_color", 75), 75.0)
        sigma_space = _floating(params.get("sigma_space", 75), 75.0)
        expression = f"cv2.bilateralFilter({input_var}, {diameter}, {sigma_color!r}, {sigma_space!r})"
    elif node_type == "Sharpen":
        amount = _floating(params.get("amount", 1.0), 1.0)
        statements.append(_statement(f"sharpen_kernel = np.array([[0, -1, 0], [-1, {4 + amount!r}, -1], [0, -1, 0]], dtype=np.float32)"))
        expression = f"cv2.filter2D({input_var}, -1, sharpen_kernel)"
    elif node_type == "Threshold":
        threshold = _integer(params.get("threshold", 127), 127)
        maximum = _integer(params.get("max_value", 255), 255)
        expression = f"cv2.threshold({_gray_expression(input_var, input_color)}, {threshold}, {maximum}, cv2.THRESH_BINARY)[1]"
        output_color = "GRAY"
    elif node_type == "OtsuThreshold":
        expression = f"cv2.threshold({_gray_expression(input_var, input_color)}, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]"
        output_color = "GRAY"
    elif node_type == "AdaptiveThreshold":
        block = _odd(params.get("block_size", 11), 11, 3)
        constant = _integer(params.get("c", 2), 2)
        gray = _gray_expression(input_var, input_color)
        expression = f"cv2.adaptiveThreshold({gray}, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, {block}, {constant})"
        output_color = "GRAY"
    elif node_type == "Canny":
        low = _integer(params.get("threshold1", 50), 50)
        high = _integer(params.get("threshold2", 150), 150)
        expression = f"cv2.Canny({_gray_expression(input_var, input_color)}, {low}, {high})"
        output_color = "GRAY"
    elif node_type == "Sobel":
        dx = _integer(params.get("dx", 1), 1)
        dy = _integer(params.get("dy", 0), 0)
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"gradient = cv2.Sobel({_gray_expression(input_var, input_color)}, cv2.CV_16S, {dx}, {dy}, ksize={size})"))
        expression = "cv2.convertScaleAbs(gradient)"
        output_color = "GRAY"
    elif node_type == "Laplacian":
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"laplacian = cv2.Laplacian({_gray_expression(input_var, input_color)}, cv2.CV_16S, ksize={size})"))
        expression = "cv2.convertScaleAbs(laplacian)"
        output_color = "GRAY"
    elif node_type in {"Erode", "Dilate", "MorphOpen", "MorphClose", "MorphGradient"}:
        size = _odd(params.get("ksize", 3), 3)
        statements.append(_statement(f"kernel = np.ones(({size}, {size}), np.uint8)"))
        if node_type == "Erode":
            iterations = max(0, _integer(params.get("iterations", 1), 1))
            expression = f"cv2.erode({input_var}, kernel, iterations={iterations})"
        elif node_type == "Dilate":
            iterations = max(0, _integer(params.get("iterations", 1), 1))
            expression = f"cv2.dilate({input_var}, kernel, iterations={iterations})"
        else:
            operation = {
                "MorphOpen": "cv2.MORPH_OPEN",
                "MorphClose": "cv2.MORPH_CLOSE",
                "MorphGradient": "cv2.MORPH_GRADIENT",
            }[node_type]
            expression = f"cv2.morphologyEx({input_var}, {operation}, kernel)"
    elif node_type == "Resize":
        scale = max(1.0, _floating(params.get("scale_percent", 50), 50.0))
        statements.extend(
            [
                _statement(f"height, width = {input_var}.shape[:2]"),
                _statement(f"new_width = max(1, int(width * {scale!r} / 100.0))"),
                _statement(f"new_height = max(1, int(height * {scale!r} / 100.0))"),
            ]
        )
        expression = f"cv2.resize({input_var}, (new_width, new_height), interpolation=cv2.INTER_AREA)"
    elif node_type == "Flip":
        code = _integer(params.get("flip_code", 1), 1)
        code = code if code in {-1, 0, 1} else 1
        expression = f"cv2.flip({input_var}, {code})"
    elif node_type == "Rotate90":
        direction = _integer(params.get("direction", 0), 0)
        rotation = {1:"cv2.ROTATE_90_COUNTERCLOCKWISE", 2:"cv2.ROTATE_180"}.get(direction, "cv2.ROTATE_90_CLOCKWISE")
        expression = f"cv2.rotate({input_var}, {rotation})"
    elif node_type == "FindContours":
        threshold = _integer(params.get("threshold", 127), 127)
        minimum = _floating(params.get("min_area", 20), 20.0)
        gray = _gray_expression(input_var, input_color)
        bgr = _bgr_expression(input_var, input_color)
        statements.extend(
            [
                _statement(f"binary = cv2.threshold({gray}, {threshold}, 255, cv2.THRESH_BINARY)[1]"),
                _statement("contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)"),
                _statement(f"canvas = {bgr}.copy()"),
                _statement("contour_count = 0"),
                ast.parse(
                    f"""for contour in contours:
    if cv2.contourArea(contour) < {minimum!r}:
        continue
    cv2.drawContours(canvas, [contour], -1, (0, 255, 0), 2)
    x, y, w, h = cv2.boundingRect(contour)
    cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 180, 255), 1)
    contour_count += 1"""
                ).body[0],
                _statement("cv2.putText(canvas, f'contours: {contour_count}', (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 255), 2)"),
            ]
        )
        expression = "canvas"
        output_color = "BGR"
    else:
        compiler = CUSTOM_SCRIPT_COMPILERS.get(node_type)
        if compiler is None:
            raise ValueError(
                f"算子暂不支持导出为独立算法脚本：{node_type}。"
                "自定义算子可在 OPERATOR_DEFINITION 中提供 script_compiler。"
            )
        statement_sources, expression, output_color = compiler(input_var, input_color, params)
        statements.extend(_statement(source) for source in statement_sources)

    return statements, expression, output_color


def generate_algorithm_script(workflow: WorkflowRequest) -> str:
    if not workflow.nodes:
        raise ValueError("流程为空，无法导出算法脚本")

    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[str]] = defaultdict(list)
    outgoing: dict[str, list[str]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge.source)
        outgoing[edge.source].append(edge.target)

    read_nodes = [
        nodes[node_id]
        for node_id in order
        if nodes[node_id].type in {"ReadImage", "BatchReadImages"}
    ]
    if len(read_nodes) != 1:
        raise ValueError("纯算法脚本要求流程中恰好包含一个单图或批量图片输入节点")

    module_body: list[ast.stmt] = [
        ast.Expr(value=ast.Constant(value="由工业视觉流程编辑器生成的纯 OpenCV 算法脚本。")),
        ast.Import(names=[ast.alias(name="argparse")]),
        ast.ImportFrom(module="pathlib", names=[ast.alias(name="Path")], level=0),
        ast.Import(names=[ast.alias(name="cv2")]),
        ast.Import(names=[ast.alias(name="numpy", asname="np")]),
    ]

    function_body: list[ast.stmt] = [
        ast.If(
            test=ast.Compare(left=ast.Name(id="input_image", ctx=ast.Load()), ops=[ast.Is()], comparators=[ast.Constant(value=None)]),
            body=[ast.Raise(exc=ast.Call(func=ast.Name(id="ValueError", ctx=ast.Load()), args=[ast.Constant(value="输入图像不能为空")], keywords=[]), cause=None)],
            orelse=[],
        )
    ]
    variables: dict[str, str] = {}
    color_spaces: dict[str, str] = {}

    for index, node_id in enumerate(order, start=1):
        raw_node = nodes[node_id]
        node_type, params = _normalize_type(raw_node.type, raw_node.params)
        variable = f"step_{index:02d}_{_safe_identifier(node_type).lower()}"
        if node_type == "ReadImage":
            function_body.append(_statement(f"{variable} = input_image"))
            variables[node_id] = variable
            color_spaces[node_id] = "BGR"
            continue

        sources = incoming[node_id]
        if len(sources) != 1:
            raise ValueError(f"节点 {node_id} 必须恰好连接一个上游节点，当前为 {len(sources)} 个")
        source_id = sources[0]
        input_var = variables[source_id]
        input_color = color_spaces[source_id]
        extra_statements, expression, output_color = _compile_operator(node_type, params, input_var, input_color)
        function_body.extend(extra_statements)
        function_body.append(ast.Assign(targets=[ast.Name(id=variable, ctx=ast.Store())], value=_expression(expression)))
        variables[node_id] = variable
        color_spaces[node_id] = output_color

    sink_ids = [node_id for node_id in order if not outgoing[node_id]]
    if not sink_ids:
        raise ValueError("流程没有终点节点")
    if len(sink_ids) == 1:
        function_body.append(ast.Return(value=ast.Name(id=variables[sink_ids[0]], ctx=ast.Load())))
    else:
        function_body.append(
            ast.Return(
                value=ast.Dict(
                    keys=[ast.Constant(value=node_id) for node_id in sink_ids],
                    values=[ast.Name(id=variables[node_id], ctx=ast.Load()) for node_id in sink_ids],
                )
            )
        )

    run_function = ast.FunctionDef(
        name="run_algorithm",
        args=ast.arguments(posonlyargs=[], args=[ast.arg(arg="input_image")], kwonlyargs=[], kw_defaults=[], defaults=[]),
        body=function_body,
        decorator_list=[],
    )
    module_body.append(run_function)

    helpers = ast.parse(
        '''
def read_image(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"无法读取图片：{path}")
    return image


def save_image(path, image):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    extension = path.suffix or ".png"
    if not path.suffix:
        path = path.with_suffix(extension)
    ok, buffer = cv2.imencode(extension, image)
    if not ok:
        raise ValueError(f"无法编码结果图：{path}")
    buffer.tofile(str(path))
    return path


def main():
    parser = argparse.ArgumentParser(description="运行导出的 OpenCV 算法")
    parser.add_argument("--input", required=True, help="输入图片路径")
    parser.add_argument("--output", default="result.png", help="输出图片路径；多结果时作为输出目录")
    args = parser.parse_args()
    result = run_algorithm(read_image(args.input))
    if isinstance(result, dict):
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        for name, image in result.items():
            save_image(output_dir / f"{name}.png", image)
    else:
        save_image(args.output, result)


if __name__ == "__main__":
    main()
'''
    )
    module_body.extend(helpers.body)

    module = ast.Module(body=module_body, type_ignores=[])
    ast.fix_missing_locations(module)
    source = "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n" + ast.unparse(module) + "\n"
    compile(source, "vision_algorithm.py", "exec")
    forbidden = ("WORKFLOW", "topological_sort", "OPERATORS", '"nodes"', '"edges"')
    if any(token in source for token in forbidden):
        raise RuntimeError("生成脚本意外包含工作流运行时结构")
    return source


# 保留旧路由导入名，生成内容已经是纯顺序算法代码。
def generate_standalone_script(workflow: WorkflowRequest) -> str:
    return generate_algorithm_script(workflow)
