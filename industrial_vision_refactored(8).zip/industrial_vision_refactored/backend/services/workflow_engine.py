from __future__ import annotations

import base64
import csv
import json
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from backend.algorithms.registry import OPERATORS, OPERATOR_META
from backend.algorithms.types import ExecutionContext
from backend.models.workflow import WorkflowEdge, WorkflowNode, WorkflowRequest
from backend.services.image_store import ImageStore


def image_to_data_url(image: np.ndarray, color_space: str = "BGR") -> str:
    if image is None:
        return ""
    if image.dtype != np.uint8:
        image = np.clip(image, 0, 255).astype(np.uint8)
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    ok, buffer = cv2.imencode(".png", encode_image)
    if not ok:
        raise ValueError("图像编码失败")
    encoded = base64.b64encode(buffer).decode("utf-8")
    return f"data:image/png;base64,{encoded}"


def topological_sort(nodes: list[WorkflowNode], edges: list[WorkflowEdge]) -> list[str]:
    node_ids = [node.id for node in nodes]
    if len(node_ids) != len(set(node_ids)):
        raise ValueError("节点 ID 不能重复")

    node_set = set(node_ids)
    indegree = {node_id: 0 for node_id in node_ids}
    graph: dict[str, list[str]] = {node_id: [] for node_id in node_ids}

    for edge in edges:
        if edge.source not in node_set or edge.target not in node_set:
            raise ValueError("存在无效连线：source 或 target 节点不存在")
        graph[edge.source].append(edge.target)
        indegree[edge.target] += 1

    queue = deque(node_id for node_id in node_ids if indegree[node_id] == 0)
    order: list[str] = []
    while queue:
        node_id = queue.popleft()
        order.append(node_id)
        for target_id in graph[node_id]:
            indegree[target_id] -= 1
            if indegree[target_id] == 0:
                queue.append(target_id)

    if len(order) != len(node_ids):
        raise ValueError("流程中存在环，请检查节点连线")
    return order


def _merge_data(target: dict[str, Any], source: Any) -> None:
    if not isinstance(source, dict):
        return
    for key, value in source.items():
        target[key] = value


def _prepare_graph(workflow: WorkflowRequest):
    order = topological_sort(workflow.nodes, workflow.edges)
    nodes = {node.id: node for node in workflow.nodes}
    incoming: dict[str, list[WorkflowEdge]] = defaultdict(list)
    outgoing: dict[str, list[WorkflowEdge]] = defaultdict(list)
    for edge in workflow.edges:
        incoming[edge.target].append(edge)
        outgoing[edge.source].append(edge)
    return order, nodes, incoming, outgoing


def _execute_once(
    workflow: WorkflowRequest,
    image_store: ImageStore,
    context: ExecutionContext,
    *,
    collect_previews: bool,
) -> tuple[list[str], dict[str, dict[str, Any]], list[dict[str, Any]]]:
    order, nodes, incoming, _outgoing = _prepare_graph(workflow)
    outputs: dict[str, dict[str, Any]] = {}
    previews: list[dict[str, Any]] = []

    for node_id in order:
        node = nodes[node_id]
        operator = OPERATORS.get(node.type)
        metadata = OPERATOR_META.get(node.type, {})
        if operator is None:
            raise ValueError(f"未知算子或尚未实现：{node.type}")

        inputs: dict[str, Any] = {}
        inherited_data: dict[str, Any] = {}
        for edge in incoming[node_id]:
            if edge.source not in outputs:
                raise ValueError(f"节点 {node_id} 的上游 {edge.source} 尚未执行")
            source_output = outputs[edge.source]
            if edge.sourceHandle not in source_output:
                raise ValueError(f"节点 {edge.source} 不存在输出端口：{edge.sourceHandle}")
            inputs[edge.targetHandle] = source_output[edge.sourceHandle]
            source_color_key = f"{edge.sourceHandle}_color_space"
            if source_color_key in source_output:
                inputs[f"{edge.targetHandle}_color_space"] = source_output[source_color_key]
            _merge_data(inherited_data, source_output.get("data"))

        if metadata.get("has_input", True) and "in" not in inputs:
            raise ValueError(f"节点 {node_id}（{node.type}）缺少输入连线")
        if not metadata.get("has_input", True) and incoming[node_id]:
            raise ValueError(f"输入节点 {node_id}（{node.type}）不应存在输入连线")

        result = operator(inputs, node.params, context)
        if not isinstance(result, dict):
            raise ValueError(f"节点 {node_id}（{node.type}）返回值必须是字典")

        out_image = result.get("out")
        if isinstance(out_image, np.ndarray) and "out_color_space" not in result:
            result["out_color_space"] = "GRAY" if out_image.ndim == 2 else inputs.get("in_color_space", "BGR")

        explicit_data = result.get("data")
        _merge_data(inherited_data, explicit_data)
        metrics = result.pop("metrics", None)
        if metrics is not None:
            if not isinstance(metrics, dict):
                raise ValueError(f"节点 {node_id}（{node.type}）的 metrics 必须是字典")
            data_key = f"{node_id}_{metadata.get('label', node.type)}"
            inherited_data[data_key] = metrics
        if inherited_data:
            result["data"] = inherited_data

        outputs[node_id] = result
        if collect_previews and isinstance(out_image, np.ndarray):
            previews.append(
                {
                    "node_id": node_id,
                    "type": node.type,
                    "label": metadata.get("label", node.type),
                    "image": image_to_data_url(out_image, result.get("out_color_space", "BGR")),
                    "data": result.get("data", {}),
                }
            )

    return order, outputs, previews


def _yes(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().upper() in {"1", "TRUE", "YES", "Y", "是", "ON"}


def _integer(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _parse_extensions(value: Any, defaults: set[str]) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set(defaults)
    extensions: set[str] = set()
    for item in text.replace(";", ",").split(","):
        suffix = item.strip().lower()
        if not suffix:
            continue
        extensions.add(suffix if suffix.startswith(".") else f".{suffix}")
    return extensions or set(defaults)


def _flatten_metrics(data: dict[str, Any]) -> dict[str, Any]:
    flat: dict[str, Any] = {}

    def visit(prefix: str, value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                visit(f"{prefix}.{key}" if prefix else str(key), child)
        elif isinstance(value, (list, tuple, set)):
            flat[prefix] = json.dumps(list(value), ensure_ascii=False)
        elif value is None or isinstance(value, (str, int, float, bool)):
            flat[prefix] = value
        else:
            flat[prefix] = json.dumps(value, ensure_ascii=False, default=str)

    visit("", data)
    return {key: value for key, value in flat.items() if key}


def _safe_csv_name(value: Any) -> str:
    name = Path(str(value or "results.csv").strip()).name
    if not name.lower().endswith(".csv"):
        name += ".csv"
    return name


def _output_suffix(source_path: Path, format_name: str) -> str:
    normalized = str(format_name or "SOURCE").upper()
    if normalized == "PNG":
        return ".png"
    if normalized == "JPG":
        return ".jpg"
    if normalized == "WEBP":
        return ".webp"
    return source_path.suffix.lower() or ".png"


def _save_result_image(path: Path, image: np.ndarray, color_space: str) -> None:
    encode_image = image
    if image.ndim == 3 and str(color_space).upper() == "RGB":
        encode_image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    path.parent.mkdir(parents=True, exist_ok=True)
    ok, buffer = cv2.imencode(path.suffix or ".png", encode_image)
    if not ok:
        raise ValueError(f"无法编码结果图：{path}")
    try:
        buffer.tofile(str(path))
    except OSError as exc:
        raise ValueError(f"无法保存结果图：{path}") from exc


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    base_fields = [
        "source_path",
        "source_name",
        "relative_path",
        "output_path",
        "status",
        "error",
    ]
    metric_fields = sorted({key for row in rows for key in row if key not in base_fields})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=base_fields + metric_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _validate_batch_workflow(workflow: WorkflowRequest):
    batch_inputs = [node for node in workflow.nodes if node.type == "BatchReadImages"]
    savers = [node for node in workflow.nodes if node.type == "SaveBatchResults"]
    single_inputs = [node for node in workflow.nodes if node.type == "ReadImage"]
    if len(batch_inputs) != 1:
        raise ValueError("批量流程必须且只能包含一个“批量读取图片”节点")
    if single_inputs:
        raise ValueError("批量流程不能同时包含“读取图像”节点")
    if len(savers) != 1:
        raise ValueError("批量流程必须且只能包含一个“保存批量结果”节点")

    order, nodes, incoming, outgoing = _prepare_graph(workflow)
    batch_node = batch_inputs[0]
    saver = savers[0]
    if incoming[batch_node.id]:
        raise ValueError("批量读取图片节点不能有上游连线")
    if len(incoming[saver.id]) != 1:
        raise ValueError("保存批量结果节点必须连接且只能连接一个上游图像节点")
    if outgoing[saver.id]:
        raise ValueError("保存批量结果节点必须是工作流末端节点")
    return order, nodes, batch_node, saver


def run_batch_workflow(workflow: WorkflowRequest, image_store: ImageStore) -> dict[str, Any]:
    order, nodes, batch_node, saver = _validate_batch_workflow(workflow)
    input_params = batch_node.params
    save_params = saver.params

    source_root = image_store.resolve_directory(str(input_params.get("folder_path") or ""))
    if source_root is None:
        raise ValueError(f"批量图片文件夹不存在或不可访问：{input_params.get('folder_path', '')}")

    extensions = _parse_extensions(input_params.get("extensions"), image_store.allowed_extensions)
    images = image_store.list_images(
        source_root,
        extensions=extensions,
        recursive=_yes(input_params.get("recursive"), True),
        limit=max(0, _integer(input_params.get("max_images"), 0)),
    )
    if not images:
        raise ValueError(f"文件夹中没有找到符合扩展名的图片：{source_root}")

    output_dir = image_store.prepare_output_directory(str(save_params.get("output_dir") or "batch_outputs"))
    save_images = _yes(save_params.get("save_images"), True)
    preserve_structure = _yes(save_params.get("preserve_structure"), True)
    continue_on_error = _yes(input_params.get("continue_on_error"), True)
    write_csv = _yes(save_params.get("write_csv"), True)
    filename_suffix = str(save_params.get("filename_suffix") or "")
    image_format = str(save_params.get("image_format") or "SOURCE")

    rows: list[dict[str, Any]] = []
    succeeded = 0
    failed = 0
    last_success_path: Path | None = None

    for index, source_path in enumerate(images, start=1):
        relative = source_path.relative_to(source_root)
        row: dict[str, Any] = {
            "source_path": str(source_path),
            "source_name": source_path.name,
            "relative_path": str(relative),
            "output_path": "",
            "status": "success",
            "error": "",
        }
        try:
            context = ExecutionContext(
                image_id=None,
                image_store=image_store,
                current_image_path=source_path,
                source_root=source_root,
                batch_index=index,
                batch_total=len(images),
            )
            _, outputs, _ = _execute_once(workflow, image_store, context, collect_previews=False)
            result = outputs[saver.id]
            result_image = result.get("out")
            if not isinstance(result_image, np.ndarray):
                raise ValueError("保存批量结果节点没有收到有效图像")

            if save_images:
                result_suffix = _output_suffix(source_path, image_format)
                relative_parent = relative.parent if preserve_structure else Path()
                destination = output_dir / relative_parent / f"{source_path.stem}{filename_suffix}{result_suffix}"
                if not preserve_structure and destination.exists():
                    destination = output_dir / f"{source_path.stem}{filename_suffix}_{index:05d}{result_suffix}"
                _save_result_image(destination, result_image, str(result.get("out_color_space", "BGR")))
                row["output_path"] = str(destination)

            row.update(_flatten_metrics(result.get("data", {})))
            succeeded += 1
            last_success_path = source_path
        except Exception as exc:  # 每张图片独立记录错误，便于批量排查。
            failed += 1
            row["status"] = "error"
            row["error"] = str(exc)
            if not continue_on_error:
                rows.append(row)
                if write_csv:
                    _write_csv(output_dir / _safe_csv_name(save_params.get("csv_filename")), rows)
                raise ValueError(f"处理图片失败：{source_path}：{exc}") from exc
        rows.append(row)

    csv_path: Path | None = None
    if write_csv:
        csv_path = output_dir / _safe_csv_name(save_params.get("csv_filename"))
        _write_csv(csv_path, rows)

    previews: list[dict[str, Any]] = []
    if last_success_path is not None:
        preview_context = ExecutionContext(
            image_id=None,
            image_store=image_store,
            current_image_path=last_success_path,
            source_root=source_root,
            batch_index=succeeded + failed,
            batch_total=len(images),
        )
        _, _, previews = _execute_once(workflow, image_store, preview_context, collect_previews=True)

    return {
        "success": True,
        "mode": "batch",
        "order": order,
        "previews": previews,
        "batch": {
            "source_dir": str(source_root),
            "output_dir": str(output_dir),
            "csv_path": str(csv_path) if csv_path else "",
            "total": len(images),
            "succeeded": succeeded,
            "failed": failed,
            "rows": rows[:100],
            "rows_truncated": len(rows) > 100,
        },
    }


def run_workflow(workflow: WorkflowRequest, image_store: ImageStore) -> dict[str, Any]:
    if not workflow.nodes:
        raise ValueError("流程为空，请先添加节点")

    has_batch_input = any(node.type == "BatchReadImages" for node in workflow.nodes)
    has_batch_saver = any(node.type == "SaveBatchResults" for node in workflow.nodes)
    if has_batch_input or has_batch_saver:
        return run_batch_workflow(workflow, image_store)

    context = ExecutionContext(image_id=workflow.image_id, image_store=image_store)
    order, outputs, previews = _execute_once(workflow, image_store, context, collect_previews=True)
    sink_data: dict[str, Any] = {}
    outgoing_ids = {edge.source for edge in workflow.edges}
    for node_id, result in outputs.items():
        if node_id not in outgoing_ids and result.get("data"):
            sink_data[node_id] = result["data"]
    return {
        "success": True,
        "mode": "single",
        "previews": previews,
        "order": order,
        "data": sink_data,
    }
