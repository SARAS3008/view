let OPERATOR_META = {};
let OPERATOR_CATALOG = {};
let nodes = [];
let edges = [];
let nodeSeq = 1;
let selectedNodeId = null;
let selectedEdgeId = null;
let connectingSourceId = null;
let connectDrag = null;
let pan = { x: -260, y: -120 };
let zoom = 0.82;
let previewCollapsed = false;
let nodeLibraryVisible = true;
let previewActionNodeId = null;
let colorPaletteNodeId = null;
let lightboxNodeId = null;
let workflowDocuments = [];
let activeWorkflowId = null;
let suppressDocumentSync = false;

const WORKSPACE_STORAGE_KEY = "vision_python_mvp_workspace_v1";
const fallbackStorage = new Map();
const nodePreviews = new Map();
const DEFAULT_NODE_COLOR = "#8d9298";
const NODE_COLORS = [
  "#8d9298", "#8a4b4d", "#8e5845", "#3f7149", "#4b4b7d",
  "#526b75", "#3d7374", "#70476c", "#8b6c37", "#151719",
];
const ICONS = { io:"⎋", color:"◐", filter:"≋", segment:"⌁", morph:"⬡", geo:"⟲", measure:"▤", custom:"✦" };
const NODE_WIDTH = 340;

const viewport = document.getElementById("viewport");
const world = document.getElementById("world");
const nodeLayer = document.getElementById("nodeLayer");
const edgeLayer = document.getElementById("edgeLayer");
const statusEl = document.getElementById("status");
const paramPanel = document.getElementById("paramPanel");
const previewPanel = document.getElementById("previewPanel");
const previewWrap = document.getElementById("previewWrap");
const previewToggleText = document.getElementById("previewToggleText");

function storageGet(key){
  try{ return window.localStorage.getItem(key); }
  catch(error){ return fallbackStorage.has(key) ? fallbackStorage.get(key) : null; }
}
function storageSet(key, value){
  const serialized = String(value);
  try{ window.localStorage.setItem(key, serialized); }
  catch(error){ fallbackStorage.set(key, serialized); }
}
function cloneData(value){
  return JSON.parse(JSON.stringify(value));
}
function createWorkflowId(){
  if(window.crypto && typeof window.crypto.randomUUID === "function") return `wf_${window.crypto.randomUUID()}`;
  return `wf_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
function emptyWorkflow(){
  return { version:"2.1", nodes:[], edges:[] };
}
function demoWorkflowDefinition(){
  return {
    version:"2.1",
    nodes:[
      { id:"n1", type:"ReadImage", position:{ x:380, y:250 }, params:{ image_path:"" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n2", type:"ColorConvert", position:{ x:790, y:250 }, params:{ mode:"GRAY" }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n3", type:"GaussianBlur", position:{ x:1200, y:250 }, params:{ ksize:5, sigma:0 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n4", type:"Canny", position:{ x:1610, y:250 }, params:{ threshold1:50, threshold2:150 }, collapsed:false, color:DEFAULT_NODE_COLOR },
      { id:"n5", type:"Display", position:{ x:2020, y:250 }, params:{}, collapsed:false, color:DEFAULT_NODE_COLOR },
    ],
    edges:[
      { id:"e1", source:"n1", sourceHandle:"out", target:"n2", targetHandle:"in" },
      { id:"e2", source:"n2", sourceHandle:"out", target:"n3", targetHandle:"in" },
      { id:"e3", source:"n3", sourceHandle:"out", target:"n4", targetHandle:"in" },
      { id:"e4", source:"n4", sourceHandle:"out", target:"n5", targetHandle:"in" },
    ],
  };
}
function workflowSignature(workflow){
  return JSON.stringify(workflow || emptyWorkflow());
}
function getActiveWorkflowDocument(){
  return workflowDocuments.find(documentInfo => documentInfo.id === activeWorkflowId) || null;
}
function nextWorkflowName(){
  const used = new Set(workflowDocuments.map(documentInfo => documentInfo.name));
  if(!used.has("Vision Workflow")) return "Vision Workflow";
  let index = 2;
  while(used.has(`Vision Workflow ${index}`)) index += 1;
  return `Vision Workflow ${index}`;
}
function createWorkflowDocument(workflow = emptyWorkflow(), options = {}){
  const name = options.name || nextWorkflowName();
  const normalizedWorkflow = cloneData(workflow);
  const saved = Boolean(options.saved);
  return {
    id:options.id || createWorkflowId(),
    name,
    workflow:normalizedWorkflow,
    savedSnapshot:saved ? workflowSignature(normalizedWorkflow) : (options.savedSnapshot || null),
    savedName:saved ? name : (options.savedName || null),
    dirty:!saved,
    view:options.view || { pan:{ x:-260, y:-120 }, zoom:.82, previewCollapsed:false, nodeLibraryVisible:true },
    selectedNodeId:options.selectedNodeId || null,
    runtimePreviews:[],
  };
}
function recomputeDocumentDirty(documentInfo){
  if(!documentInfo) return;
  documentInfo.dirty = !documentInfo.savedSnapshot
    || documentInfo.savedSnapshot !== workflowSignature(documentInfo.workflow)
    || documentInfo.savedName !== documentInfo.name;
}
function persistWorkspace(){
  try{
    const payload = {
      version:1,
      activeWorkflowId,
      documents:workflowDocuments.map(documentInfo => ({
        id:documentInfo.id,
        name:documentInfo.name,
        workflow:documentInfo.workflow,
        savedSnapshot:documentInfo.savedSnapshot,
        savedName:documentInfo.savedName,
        view:documentInfo.view,
        selectedNodeId:documentInfo.selectedNodeId,
      })),
    };
    storageSet(WORKSPACE_STORAGE_KEY, JSON.stringify(payload));
  }catch(error){
    console.warn("无法保存工作区状态", error);
  }
}
function captureActiveWorkflowDocument(recalculateDirty = true){
  if(suppressDocumentSync) return;
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  documentInfo.workflow = buildWorkflow();
  documentInfo.view = {
    pan:{ ...pan },
    zoom,
    previewCollapsed,
    nodeLibraryVisible,
  };
  documentInfo.selectedNodeId = selectedNodeId;
  documentInfo.runtimePreviews = Array.from(nodePreviews.values());
  if(recalculateDirty) recomputeDocumentDirty(documentInfo);
}
function commitActiveWorkflowChange(){
  captureActiveWorkflowDocument(true);
  renderWorkflowTabs();
  persistWorkspace();
}
function persistActiveWorkflowView(){
  captureActiveWorkflowDocument(false);
  persistWorkspace();
}
function renderWorkflowTabs(){
  const container = document.getElementById("workflowTabs");
  if(!container) return;
  container.innerHTML = "";
  workflowDocuments.forEach(documentInfo => {
    const tab = document.createElement("div");
    tab.className = `workflow-tab ${documentInfo.id === activeWorkflowId ? "active" : ""}`;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-selected", String(documentInfo.id === activeWorkflowId));
    tab.dataset.workflowId = documentInfo.id;

    const main = document.createElement("button");
    main.type = "button";
    main.className = "workflow-tab-main";
    main.title = `${documentInfo.name} · ${documentInfo.dirty ? "未保存" : "已保存"}（双击重命名）`;
    const name = document.createElement("span");
    name.className = "workflow-tab-name";
    name.textContent = documentInfo.name;
    const dot = document.createElement("span");
    dot.className = `save-state-dot ${documentInfo.dirty ? "dirty" : "saved"}`;
    dot.title = documentInfo.dirty ? "有未保存修改" : "已保存";
    main.append(name, dot);
    main.addEventListener("click", () => switchWorkflow(documentInfo.id));
    main.addEventListener("dblclick", event => {
      event.preventDefault();
      renameWorkflow(documentInfo.id);
    });

    const close = document.createElement("button");
    close.type = "button";
    close.className = "workflow-tab-close";
    close.textContent = "×";
    close.title = "关闭工作流";
    close.setAttribute("aria-label", `关闭 ${documentInfo.name}`);
    close.addEventListener("click", event => {
      event.stopPropagation();
      closeWorkflow(documentInfo.id);
    });
    tab.append(main, close);
    container.appendChild(tab);
  });
  window.requestAnimationFrame(() => {
    container.querySelector(".workflow-tab.active")?.scrollIntoView({ block:"nearest", inline:"nearest" });
  });
}
function restoreWorkflowDocument(documentInfo){
  if(!documentInfo) return;
  suppressDocumentSync = true;
  try{
    closeImageLightbox();
    applyWorkflow(cloneData(documentInfo.workflow), { silent:true });
    pan = { ...(documentInfo.view?.pan || { x:-260, y:-120 }) };
    zoom = Number(documentInfo.view?.zoom) || .82;
    applyTransform();
    setNodeLibraryVisible(documentInfo.view?.nodeLibraryVisible !== false);
    togglePreviewPanel(Boolean(documentInfo.view?.previewCollapsed));
    selectedNodeId = nodes.some(node => node.id === documentInfo.selectedNodeId) ? documentInfo.selectedNodeId : (nodes[0]?.id || null);
    selectedEdgeId = null;
    nodePreviews.clear();
    (documentInfo.runtimePreviews || []).forEach(item => nodePreviews.set(item.node_id, item));
    if(documentInfo.runtimePreviews?.length) renderPreviews(documentInfo.runtimePreviews);
    else{
      previewPanel.innerHTML = '<div class="empty-preview">运行后显示每步处理结果</div>';
      render();
    }
    setStatus(`当前工作流：${documentInfo.name}${documentInfo.dirty ? "（未保存）" : "（已保存）"}`);
  }finally{
    suppressDocumentSync = false;
  }
}
function switchWorkflow(workflowId){
  if(workflowId === activeWorkflowId) return;
  const target = workflowDocuments.find(documentInfo => documentInfo.id === workflowId);
  if(!target) return;
  captureActiveWorkflowDocument(true);
  activeWorkflowId = workflowId;
  restoreWorkflowDocument(target);
  renderWorkflowTabs();
  persistWorkspace();
}
function newWorkflow(){
  captureActiveWorkflowDocument(true);
  const documentInfo = createWorkflowDocument(emptyWorkflow());
  workflowDocuments.push(documentInfo);
  activeWorkflowId = documentInfo.id;
  restoreWorkflowDocument(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  toast("已新建工作流", documentInfo.name, true);
}
function closeWorkflow(workflowId){
  const index = workflowDocuments.findIndex(documentInfo => documentInfo.id === workflowId);
  if(index < 0) return;
  const documentInfo = workflowDocuments[index];
  if(documentInfo.dirty && !window.confirm(`“${documentInfo.name}”存在未保存修改，确定关闭吗？`)) return;
  const wasActive = workflowId === activeWorkflowId;
  workflowDocuments.splice(index, 1);
  if(!workflowDocuments.length){
    const replacement = createWorkflowDocument(emptyWorkflow());
    workflowDocuments.push(replacement);
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }else if(wasActive){
    const replacement = workflowDocuments[Math.min(index, workflowDocuments.length - 1)];
    activeWorkflowId = replacement.id;
    restoreWorkflowDocument(replacement);
  }
  renderWorkflowTabs();
  persistWorkspace();
}
function renameWorkflow(workflowId){
  const documentInfo = workflowDocuments.find(item => item.id === workflowId);
  if(!documentInfo) return;
  const nextName = window.prompt("请输入工作流名称", documentInfo.name);
  if(nextName === null) return;
  const trimmed = nextName.trim();
  if(!trimmed || trimmed === documentInfo.name) return;
  documentInfo.name = trimmed;
  recomputeDocumentDirty(documentInfo);
  renderWorkflowTabs();
  persistWorkspace();
  setStatus(`工作流已重命名为：${trimmed}`);
}
function initializeWorkspace(){
  let restored = false;
  try{
    const raw = storageGet(WORKSPACE_STORAGE_KEY);
    if(raw){
      const payload = JSON.parse(raw);
      workflowDocuments = (payload.documents || []).map(rawDocument => {
        const documentInfo = createWorkflowDocument(rawDocument.workflow || emptyWorkflow(), {
          id:rawDocument.id,
          name:rawDocument.name || "Vision Workflow",
          savedSnapshot:rawDocument.savedSnapshot || null,
          savedName:rawDocument.savedName || null,
          view:rawDocument.view,
          selectedNodeId:rawDocument.selectedNodeId,
        });
        recomputeDocumentDirty(documentInfo);
        return documentInfo;
      });
      if(workflowDocuments.length){
        activeWorkflowId = workflowDocuments.some(item => item.id === payload.activeWorkflowId)
          ? payload.activeWorkflowId
          : workflowDocuments[0].id;
        restored = true;
      }
    }
  }catch(error){
    console.warn("工作区恢复失败", error);
  }

  if(!restored){
    const legacyRaw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(legacyRaw){
      try{
        const legacyDocument = createWorkflowDocument(JSON.parse(legacyRaw), { name:"Vision Workflow", saved:true });
        workflowDocuments = [legacyDocument];
        activeWorkflowId = legacyDocument.id;
        restored = true;
      }catch(error){
        console.warn("旧版流程恢复失败", error);
      }
    }
  }

  if(!restored){
    const firstDocument = createWorkflowDocument(demoWorkflowDefinition(), { name:"Vision Workflow" });
    workflowDocuments = [firstDocument];
    activeWorkflowId = firstDocument.id;
  }
  restoreWorkflowDocument(getActiveWorkflowDocument());
  renderWorkflowTabs();
  persistWorkspace();
}

async function initOperators(){
  try{
    const data = await VisionApi.getOperators();
    OPERATOR_META = data.operators || {};
    OPERATOR_CATALOG = data.catalog || {};
    renderOperatorPanel();
    applyTransform();
    initializeWorkspace();
  }catch(error){
    toast("初始化失败", error.message || String(error));
    setStatus(`初始化失败：${error.message || error}`);
  }
}

function renderOperatorPanel(){
  const panel = document.getElementById("operatorPanel");
  panel.innerHTML = "";
  const q = document.getElementById("opSearch").value.trim().toLowerCase();
  const groups = OPERATOR_CATALOG["图像"] || [];
  groups.forEach(groupInfo => {
    const matched = groupInfo.items.filter(type => {
      const meta = OPERATOR_META[type] || {};
      if(meta.hidden) return false;
      const haystack = `${type} ${meta.label || ""} ${meta.description || ""} ${groupInfo.group}`.toLowerCase();
      return !q || haystack.includes(q);
    });
    if(!matched.length) return;

    const group = document.createElement("div");
    group.className = "op-group";
    const title = document.createElement("div");
    title.className = "group-title";
    title.innerHTML = `<span class="chev">▾</span>${escapeHtml(groupInfo.group)}<span style="color:#707b8d;font-weight:700">${matched.length}</span>`;
    title.onclick = () => group.classList.toggle("closed");

    const ops = document.createElement("div");
    ops.className = "ops";
    matched.forEach(type => {
      const meta = OPERATOR_META[type];
      const op = document.createElement("div");
      op.className = "op";
      op.draggable = true;
      op.dataset.type = type;
      op.innerHTML = `<div class="op-icon" style="background:${kindColor(meta.kind)}">${ICONS[meta.kind] || "□"}</div><div><div class="op-name">${escapeHtml(meta.label)}</div><div class="op-desc">${escapeHtml(meta.description || type)}</div></div><div class="op-type">${escapeHtml(type)}</div>`;
      op.ondragstart = event => event.dataTransfer.setData("operator/type", type);
      op.ondblclick = () => addNode(type, 460 + nodes.length * 28, 240 + nodes.length * 22);
      ops.appendChild(op);
    });
    group.append(title, ops);
    panel.appendChild(group);
  });
}

function kindColor(kind){
  return { io:"#6c7177", color:"#555987", filter:"#406c88", segment:"#80604a", morph:"#47705f", geo:"#72547f", measure:"#7a4c59", custom:"#576b7a" }[kind] || "#555a61";
}

function setNodeLibraryVisible(visible){
  nodeLibraryVisible = Boolean(visible);
  const main = document.querySelector(".main");
  const library = document.getElementById("nodeLibrary");
  const toggle = document.getElementById("nodeLibraryToggle");
  main.classList.toggle("nodes-panel-hidden", !nodeLibraryVisible);
  library.setAttribute("aria-hidden", String(!nodeLibraryVisible));
  toggle.classList.toggle("active", nodeLibraryVisible);
  toggle.setAttribute("aria-expanded", String(nodeLibraryVisible));
  toggle.title = nodeLibraryVisible ? "隐藏节点库" : "显示节点库";
  window.requestAnimationFrame(updateMinimap);
  if(!suppressDocumentSync) persistActiveWorkflowView();
}
function toggleNodeLibrary(){ setNodeLibraryVisible(!nodeLibraryVisible); }

function defaultParams(type){
  return JSON.parse(JSON.stringify((OPERATOR_META[type] && OPERATOR_META[type].params) || {}));
}

function normalizeNodeType(type, params = {}){
  if(type === "Gray") return { type:"ColorConvert", params:{ ...params, mode:"GRAY" } };
  if(type === "BGR2RGB") return { type:"ColorConvert", params:{ ...params, mode:"RGB" } };
  return { type, params };
}

function addNode(type, x, y){
  const normalized = normalizeNodeType(type, defaultParams(type));
  if(!OPERATOR_META[normalized.type]){
    toast("不能添加节点", `${type} 尚未实现`);
    return;
  }
  const id = `n${nodeSeq++}`;
  nodes.push({
    id,
    type:normalized.type,
    position:{ x:Math.round(x), y:Math.round(y) },
    params:Object.keys(normalized.params).length ? normalized.params : defaultParams(normalized.type),
    collapsed:false,
    color:DEFAULT_NODE_COLOR,
  });
  selectedNodeId = id;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已添加节点：${id} · ${OPERATOR_META[normalized.type].label}`);
}

function clampZoom(value){ return Math.min(2.6, Math.max(0.18, value)); }
function applyTransform(){
  world.style.transform = `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`;
  document.getElementById("zoomLabel").textContent = `${Math.round(zoom * 100)}%`;
  const small = 20 * zoom;
  const large = 100 * zoom;
  viewport.style.backgroundSize = `${small}px ${small}px, ${small}px ${small}px, ${large}px ${large}px, ${large}px ${large}px`;
  viewport.style.backgroundPosition = `${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px, ${pan.x}px ${pan.y}px`;
  updateMinimap();
}
function screenToWorld(clientX, clientY){
  const rect = viewport.getBoundingClientRect();
  return { x:(clientX - rect.left - pan.x) / zoom, y:(clientY - rect.top - pan.y) / zoom, sx:clientX - rect.left, sy:clientY - rect.top };
}
function setZoom(value, center){
  const next = clampZoom(value);
  if(center){
    pan.x = center.sx - center.x * next;
    pan.y = center.sy - center.y * next;
  }
  zoom = next;
  applyTransform();
  persistActiveWorkflowView();
}
function zoomBy(delta, clientX, clientY){
  const center = screenToWorld(clientX, clientY);
  setZoom(zoom * (delta > 0 ? 1.1 : 1 / 1.1), center);
}
function isCanvasEmptyTarget(target){
  if(!target) return false;
  if(target.closest && target.closest(".node,.port,.canvas-toolbar,.bottom-controls,.toast,button,input,label,textarea,select")) return false;
  return target === viewport || target === world || target === nodeLayer || target === edgeLayer || target.tagName === "svg" || target.tagName === "path";
}

viewport.addEventListener("wheel", event => {
  event.preventDefault();
  zoomBy(event.deltaY < 0 ? 1 : -1, event.clientX, event.clientY);
}, { passive:false });
viewport.addEventListener("dragover", event => event.preventDefault());
viewport.addEventListener("drop", event => {
  event.preventDefault();
  const type = event.dataTransfer.getData("operator/type");
  if(!type) return;
  const point = screenToWorld(event.clientX, event.clientY);
  addNode(type, point.x, point.y);
});
viewport.addEventListener("mousedown", event => {
  if(event.button !== 0 || !isCanvasEmptyTarget(event.target)) return;
  event.preventDefault();
  selectedNodeId = null;
  selectedEdgeId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...pan };
  viewport.classList.add("panning");
  function move(moveEvent){
    pan.x = start.x + moveEvent.clientX - startX;
    pan.y = start.y + moveEvent.clientY - startY;
    applyTransform();
  }
  function up(){
    viewport.classList.remove("panning");
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    persistActiveWorkflowView();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
});

function render(){
  renderNodes();
  renderEdges();
  renderParams();
  updateMinimap();
}

function nodeHeight(node){
  if(node.collapsed) return 58;
  const meta = OPERATOR_META[node.type] || { params:{} };
  const count = Object.keys(meta.params || {}).length;
  return 178 + Math.max(1, count) * 48 + 206;
}

function renderNodes(){
  nodeLayer.innerHTML = "";
  nodes.forEach(node => {
    const meta = OPERATOR_META[node.type] || { label:node.type, params:{}, has_input:true, has_output:true };
    const selected = selectedNodeId === node.id;
    const preview = nodePreviews.get(node.id);
    const accent = safeColor(node.color || DEFAULT_NODE_COLOR);
    const element = document.createElement("div");
    element.className = `node ${selected ? "selected" : ""} ${node.collapsed ? "collapsed" : ""}`;
    element.dataset.id = node.id;
    element.style.left = `${node.position.x}px`;
    element.style.top = `${node.position.y}px`;
    element.style.setProperty("--node-accent", accent);

    element.innerHTML = `
      ${selected ? renderNodeToolbarHtml(node) : ""}
      ${selected && colorPaletteNodeId === node.id ? renderColorPaletteHtml(node) : ""}
      <div class="node-head">
        <div class="node-title"><button class="fold-btn" type="button" title="折叠/展开">▾</button><span>${escapeHtml(meta.label)}</span></div>
        <div class="node-badge">${escapeHtml(node.id)}</div>
      </div>
      ${meta.has_input ? '<div class="port in" title="输入图像"></div>' : ""}
      ${meta.has_output ? '<div class="port out" title="输出图像"></div>' : ""}
      <div class="node-body">
        <div class="socket-row"><span>${meta.has_input ? "图像" : "输入"}</span><span>${meta.has_output ? "图像" : "输出"}</span></div>
        <div class="node-param-list"></div>
        <div class="node-effect">
          <div class="node-effect-title"><span>节点效果</span><span class="${preview ? "result-ready" : ""}">${preview ? "已生成" : "等待运行"}</span></div>
          ${renderNodePreviewHtml(node, preview)}
        </div>
      </div>`;

    attachNodeEvents(element, node, meta);
    renderNodeParameterControls(element.querySelector(".node-param-list"), node, meta);
    nodeLayer.appendChild(element);
  });
}

function renderNodeToolbarHtml(node){
  return `<div class="node-toolbar" data-stop-node-drag>
    <button type="button" data-node-action="delete" title="删除节点">⌫</button>
    <span class="divider"></span>
    <button type="button" data-node-action="info" title="查看节点信息">ⓘ</button>
    <button type="button" class="node-color-button" data-node-action="color" title="更改节点配色">●</button>
    <button type="button" data-node-action="duplicate" title="复制节点">⧉</button>
    <button type="button" data-node-action="collapse" title="${node.collapsed ? "展开节点" : "折叠节点"}">↕</button>
  </div>`;
}

function renderColorPaletteHtml(node){
  const current = safeColor(node.color || DEFAULT_NODE_COLOR);
  return `<div class="node-color-palette" data-stop-node-drag>${NODE_COLORS.map(color => `<button type="button" class="node-color-swatch ${color === current ? "active" : ""}" style="background:${color}" data-node-color="${color}" title="使用 ${color}"></button>`).join("")}</div>`;
}

function renderNodePreviewHtml(node, preview){
  if(!preview){
    return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}"><div class="node-effect-empty">运行流程后，这里会显示当前节点的完整缩略图</div></div>`;
  }
  const showActions = previewActionNodeId === node.id;
  return `<div class="node-effect-frame" data-preview-node="${escapeHtml(node.id)}" title="点击显示图片操作">
    <img src="${preview.image}" alt="${escapeHtml(preview.label || node.id)} 的处理结果" />
    <span class="node-effect-hint">点击显示下载和放大按钮</span>
    ${showActions ? `<div class="node-effect-actions" data-stop-node-drag>
      <button type="button" data-preview-action="download">⇩ 下载</button>
      <button type="button" class="primary" data-preview-action="zoom">⛶ 放大</button>
    </div>` : ""}
  </div>`;
}

function attachNodeEvents(element, node, meta){
  element.addEventListener("mousedown", event => {
    if(event.target.closest("input,select,button,.node-effect-frame,.node-color-palette")) return;
    if(selectedNodeId !== node.id){
      selectedNodeId = node.id;
      selectedEdgeId = null;
      colorPaletteNodeId = null;
      render();
    }
  });

  const head = element.querySelector(".node-head");
  head.addEventListener("mousedown", event => startDragNode(event, node.id));
  element.querySelector(".fold-btn").addEventListener("click", event => {
    event.stopPropagation();
    node.collapsed = !node.collapsed;
    render();
    commitActiveWorkflowChange();
  });

  element.querySelectorAll("[data-node-action]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      const action = button.dataset.nodeAction;
      if(action === "delete") deleteNode(node.id);
      else if(action === "info"){
        setStatus(`${node.id} · ${meta.label}：${meta.description || "暂无说明"}`);
        toast("节点说明", meta.description || meta.label, true);
      }else if(action === "color"){
        colorPaletteNodeId = colorPaletteNodeId === node.id ? null : node.id;
        renderNodes();
      }else if(action === "duplicate") duplicateNode(node.id);
      else if(action === "collapse"){
        node.collapsed = !node.collapsed;
        render();
        commitActiveWorkflowChange();
      }
    });
  });

  element.querySelectorAll("[data-node-color]").forEach(button => {
    button.addEventListener("mousedown", event => event.stopPropagation());
    button.addEventListener("click", event => {
      event.stopPropagation();
      node.color = safeColor(button.dataset.nodeColor);
      colorPaletteNodeId = null;
      renderNodes();
      commitActiveWorkflowChange();
      setStatus(`已更新 ${node.id} 的节点配色`);
    });
  });

  const previewFrame = element.querySelector(".node-effect-frame");
  previewFrame.addEventListener("mousedown", event => event.stopPropagation());
  previewFrame.addEventListener("click", event => {
    event.stopPropagation();
    selectedNodeId = node.id;
    selectedEdgeId = null;
    if(!nodePreviews.has(node.id)){
      render();
      return;
    }
    previewActionNodeId = previewActionNodeId === node.id ? null : node.id;
    renderNodes();
    renderParams();
  });
  const downloadButton = element.querySelector('[data-preview-action="download"]');
  if(downloadButton){
    downloadButton.addEventListener("click", event => {
      event.stopPropagation();
      downloadNodePreview(node.id);
    });
  }
  const zoomButton = element.querySelector('[data-preview-action="zoom"]');
  if(zoomButton){
    zoomButton.addEventListener("click", event => {
      event.stopPropagation();
      openImageLightbox(node.id);
    });
  }

  const outPort = element.querySelector(".port.out");
  if(outPort){
    outPort.onclick = event => { event.stopPropagation(); startConnect(node.id); };
    outPort.addEventListener("mousedown", event => startConnectDrag(event, node.id));
  }
  const inPort = element.querySelector(".port.in");
  if(inPort){
    inPort.onclick = event => {
      event.stopPropagation();
      if(connectingSourceId) finishConnect(node.id);
      else selectIncomingEdge(node.id);
    };
    inPort.addEventListener("mousedown", event => {
      if(connectingSourceId){
        event.stopPropagation();
        finishConnect(node.id);
      }
    });
  }
}

function renderNodeParameterControls(container, node, meta){
  const keys = Object.keys(meta.params || {});
  if(!keys.length){
    const empty = document.createElement("div");
    empty.className = "node-no-params";
    empty.textContent = "该节点没有可调参数";
    container.appendChild(empty);
    return;
  }

  keys.forEach(key => {
    const schema = (meta.param_schema || {})[key] || {};
    const value = node.params[key] ?? meta.params[key];
    const row = document.createElement("div");
    row.className = "node-param-row";
    const label = document.createElement("div");
    label.className = "node-param-label";
    label.textContent = schema.label || humanizeParam(key);
    label.title = schema.label || key;
    const control = document.createElement("div");
    control.className = "node-param-control";

    if(schema.type === "select"){
      const select = document.createElement("select");
      select.className = "node-param-select";
      (schema.options || []).forEach(optionInfo => {
        const option = document.createElement("option");
        option.value = optionInfo.value;
        option.textContent = optionInfo.label;
        option.selected = String(optionInfo.value) === String(value);
        select.appendChild(option);
      });
      select.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      select.onchange = () => updateNodeParam(node.id, key, select.value);
      control.appendChild(select);
    }else if(schema.type === "text" || typeof value === "string"){
      const input = document.createElement("input");
      input.className = "node-param-input";
      input.type = "text";
      input.value = value ?? "";
      input.placeholder = schema.placeholder || "";
      input.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event));
      input.onchange = () => updateNodeParam(node.id, key, input.value);
      control.appendChild(input);
    }else{
      const stepper = document.createElement("div");
      stepper.className = "node-param-stepper";
      const minus = document.createElement("button");
      minus.type = "button";
      minus.textContent = "−";
      const input = document.createElement("input");
      input.type = "number";
      input.value = value;
      input.step = numericStep(value, key);
      const plus = document.createElement("button");
      plus.type = "button";
      plus.textContent = "+";
      [minus, input, plus].forEach(item => item.addEventListener("mousedown", event => selectNodeWithoutRerender(node.id, event)));
      minus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) - step);
      };
      plus.onclick = event => {
        event.stopPropagation();
        const step = Number(input.step) || 1;
        updateNodeParam(node.id, key, numberValue(value) + step);
      };
      input.onchange = () => updateNodeParam(node.id, key, Number(input.value));
      stepper.append(minus, input, plus);
      control.appendChild(stepper);
    }

    row.append(label, control);
    if(schema.help){
      const help = document.createElement("div");
      help.className = "node-param-help";
      help.textContent = schema.help;
      row.appendChild(help);
    }
    container.appendChild(row);
  });
}

function selectNodeWithoutRerender(nodeId, event){
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  document.querySelectorAll(".node").forEach(element => element.classList.toggle("selected", element.dataset.id === nodeId));
  renderParams();
}

function humanizeParam(key){
  const names = {
    image_path:"图片路径", mode:"转换模式", ksize:"核尺寸", sigma:"Sigma", clip_limit:"裁剪限制",
    tile_grid:"网格大小", d:"邻域直径", sigma_color:"颜色 Sigma", sigma_space:"空间 Sigma",
    amount:"锐化强度", threshold:"阈值", max_value:"最大值", block_size:"块大小", c:"常数 C",
    threshold1:"低阈值", threshold2:"高阈值", dx:"X 阶数", dy:"Y 阶数", iterations:"迭代次数",
    scale_percent:"缩放百分比", flip_code:"翻转模式", direction:"旋转方向", min_area:"最小面积",
  };
  return names[key] || key;
}
function numericStep(value, key){
  if(["sigma", "clip_limit", "amount", "min_area"].includes(key) || !Number.isInteger(Number(value))) return "0.1";
  return "1";
}
function numberValue(value){
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
function updateNodeParam(nodeId, key, value){
  const node = nodes.find(item => item.id === nodeId);
  if(!node) return;
  node.params[key] = value;
  invalidateNodeAndDownstreamPreviews(nodeId);
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已更新参数：${node.id}.${key} = ${value}；请重新运行流程`);
}
function invalidateNodeAndDownstreamPreviews(nodeId){
  const pending = [nodeId];
  const affected = new Set();
  while(pending.length){
    const current = pending.shift();
    if(affected.has(current)) continue;
    affected.add(current);
    edges.filter(edge => edge.source === current).forEach(edge => pending.push(edge.target));
  }
  affected.forEach(id => nodePreviews.delete(id));
  if(affected.has(previewActionNodeId)) previewActionNodeId = null;
  if(affected.has(lightboxNodeId)) closeImageLightbox();
}

function startConnect(id){
  const sourceMeta = OPERATOR_META[nodes.find(node => node.id === id)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); return; }
  connectingSourceId = id;
  selectedEdgeId = null;
  renderEdges();
  setStatus(`请选择目标节点输入端口：${id}.out → ?`);
}
function startConnectDrag(event, id){
  if(event.button !== 0) return;
  event.stopPropagation();
  event.preventDefault();
  startConnect(id);
  connectDrag = { source:id };
  drawTempEdge(event.clientX, event.clientY);
  function move(moveEvent){ drawTempEdge(moveEvent.clientX, moveEvent.clientY); }
  function up(upEvent){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    clearTempEdge();
    const target = document.elementFromPoint(upEvent.clientX, upEvent.clientY);
    const port = target && target.closest ? target.closest(".port.in") : null;
    const nodeElement = port && port.closest ? port.closest(".node") : null;
    const targetId = nodeElement ? nodeElement.dataset.id : null;
    if(targetId) finishConnect(targetId);
    else setStatus(`已选择源端口：${id}.out，请点击目标节点输入端口`);
    connectDrag = null;
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function finishConnect(targetId){
  if(!connectingSourceId || connectingSourceId === targetId) return;
  const sourceMeta = OPERATOR_META[nodes.find(node => node.id === connectingSourceId)?.type] || {};
  const targetMeta = OPERATOR_META[nodes.find(node => node.id === targetId)?.type] || {};
  if(!sourceMeta.has_output){ toast("连线失败", "源节点没有输出端口"); connectingSourceId = null; return; }
  if(!targetMeta.has_input){ toast("连线失败", "目标节点没有输入端口"); connectingSourceId = null; return; }
  edges = edges.filter(edge => !(edge.target === targetId && edge.targetHandle === "in"));
  const edgeId = `e${Date.now()}`;
  edges.push({ id:edgeId, source:connectingSourceId, sourceHandle:"out", target:targetId, targetHandle:"in" });
  const message = `${connectingSourceId} → ${targetId}`;
  invalidateNodeAndDownstreamPreviews(targetId);
  connectingSourceId = null;
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  render();
  commitActiveWorkflowChange();
  setStatus(`已创建连线：${message}`);
  toast("已创建连线", message, true);
}
function startDragNode(event, nodeId){
  if(event.button !== 0 || event.target.closest("button,input,select")) return;
  event.stopPropagation();
  selectedNodeId = nodeId;
  selectedEdgeId = null;
  const node = nodes.find(item => item.id === nodeId);
  const startX = event.clientX;
  const startY = event.clientY;
  const start = { ...node.position };
  function move(moveEvent){
    node.position.x = Math.round(start.x + (moveEvent.clientX - startX) / zoom);
    node.position.y = Math.round(start.y + (moveEvent.clientY - startY) / zoom);
    renderNodes();
    renderEdges();
    updateMinimap();
  }
  function up(){
    window.removeEventListener("mousemove", move);
    window.removeEventListener("mouseup", up);
    renderParams();
    if(node.position.x !== start.x || node.position.y !== start.y) commitActiveWorkflowChange();
  }
  window.addEventListener("mousemove", move);
  window.addEventListener("mouseup", up);
}
function getPortPoint(node, kind){
  const y = node.position.y + (node.collapsed ? 27 : 74);
  return { x:node.position.x + (kind === "out" ? NODE_WIDTH : 0), y };
}
function makeEdgePath(start, end){
  const control1 = start.x + 105;
  const control2 = end.x - 105;
  return `M ${start.x} ${start.y} C ${control1} ${start.y}, ${control2} ${end.y}, ${end.x} ${end.y}`;
}
function drawTempEdge(clientX, clientY){
  clearTempEdge();
  const source = nodes.find(node => node.id === connectingSourceId);
  if(!source) return;
  const start = getPortPoint(source, "out");
  const end = screenToWorld(clientX, clientY);
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.id = "tempEdge";
  path.setAttribute("class", "edge-temp");
  path.setAttribute("d", makeEdgePath(start, end));
  edgeLayer.appendChild(path);
}
function clearTempEdge(){
  const temporary = document.getElementById("tempEdge");
  if(temporary) temporary.remove();
}
function renderEdges(){
  edgeLayer.innerHTML = "";
  edges.forEach(edge => {
    const source = nodes.find(node => node.id === edge.source);
    const target = nodes.find(node => node.id === edge.target);
    if(!source || !target) return;
    const pathData = makeEdgePath(getPortPoint(source, "out"), getPortPoint(target, "in"));
    const hit = document.createElementNS("http://www.w3.org/2000/svg", "path");
    hit.setAttribute("d", pathData);
    hit.setAttribute("class", "edge-hit");
    hit.dataset.id = edge.id;
    hit.addEventListener("mousedown", event => event.stopPropagation());
    hit.addEventListener("click", event => { event.stopPropagation(); selectEdge(edge.id); });
    hit.addEventListener("dblclick", event => { event.stopPropagation(); deleteEdge(edge.id); });
    hit.addEventListener("contextmenu", event => { event.preventDefault(); event.stopPropagation(); deleteEdge(edge.id); });
    const visible = document.createElementNS("http://www.w3.org/2000/svg", "path");
    visible.setAttribute("d", pathData);
    visible.setAttribute("class", `edge-visible ${selectedEdgeId === edge.id ? "selected" : ""}`);
    edgeLayer.append(hit, visible);
  });
}
function selectIncomingEdge(targetId){
  const edge = edges.find(item => item.target === targetId && item.targetHandle === "in");
  if(edge) selectEdge(edge.id);
}
function selectEdge(edgeId){
  selectedEdgeId = edgeId;
  selectedNodeId = null;
  connectingSourceId = null;
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  render();
  const edge = edges.find(item => item.id === edgeId);
  if(edge) setStatus(`已选择连线：${edge.source} → ${edge.target}，按 Delete/Backspace 删除`);
}
function deleteEdge(edgeId){
  const edge = edges.find(item => item.id === edgeId);
  if(!edge) return;
  edges = edges.filter(item => item.id !== edgeId);
  if(selectedEdgeId === edgeId) selectedEdgeId = null;
  invalidateNodeAndDownstreamPreviews(edge.target);
  render();
  commitActiveWorkflowChange();
  toast("已删除连线", `${edge.source} → ${edge.target}`, true);
}
function deleteSelectedEdge(){ if(selectedEdgeId) deleteEdge(selectedEdgeId); }

function renderParams(){
  if(selectedEdgeId && !selectedNodeId){
    const edge = edges.find(item => item.id === selectedEdgeId);
    if(edge){
      paramPanel.className = "param-card";
      paramPanel.innerHTML = `<h3>连线 · ${escapeHtml(edge.source)} → ${escapeHtml(edge.target)}</h3><div class="hint">双击、右键或按 Delete 可以删除这条连线。</div><div class="row-actions"><button class="btn red" onclick="deleteSelectedEdge()">删除连线</button></div>`;
      return;
    }
  }
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node){
    paramPanel.className = "param-card hint";
    paramPanel.innerHTML = "请选择一个节点或连线";
    return;
  }
  const meta = OPERATOR_META[node.type] || { label:node.type };
  const previewState = nodePreviews.has(node.id) ? "已生成节点效果预览" : "尚未生成节点效果预览";
  paramPanel.className = "param-card";
  paramPanel.innerHTML = `<h3>${escapeHtml(node.id)} · ${escapeHtml(meta.label)}</h3><div class="hint">类型：${escapeHtml(node.type)}<br>${escapeHtml(meta.description || "")}<br>${previewState}<br><br>所有可调参数都在节点卡片内编辑。</div><div class="row-actions"><button class="btn ghost" onclick="duplicateNode('${escapeHtml(node.id)}')">复制节点</button><button class="btn red" onclick="deleteNode('${escapeHtml(node.id)}')">删除节点</button></div>`;
}
function toggleSelectedCollapse(){
  const node = nodes.find(item => item.id === selectedNodeId);
  if(!node) return;
  node.collapsed = !node.collapsed;
  render();
  commitActiveWorkflowChange();
}
function collapseAllNodes(){ nodes.forEach(node => node.collapsed = true); render(); commitActiveWorkflowChange(); setStatus("已折叠所有节点"); }
function expandAllNodes(){ nodes.forEach(node => node.collapsed = false); render(); commitActiveWorkflowChange(); setStatus("已展开所有节点"); }
function duplicateNode(id){
  const source = nodes.find(item => item.id === id);
  if(!source) return;
  const newId = `n${nodeSeq++}`;
  nodes.push({
    id:newId,
    type:source.type,
    position:{ x:source.position.x + 42, y:source.position.y + 42 },
    params:JSON.parse(JSON.stringify(source.params || {})),
    collapsed:source.collapsed,
    color:source.color || DEFAULT_NODE_COLOR,
  });
  selectedNodeId = newId;
  selectedEdgeId = null;
  colorPaletteNodeId = null;
  render();
  commitActiveWorkflowChange();
}
function deleteNode(id){
  if(!nodes.some(node => node.id === id)) return;
  nodes = nodes.filter(node => node.id !== id);
  edges = edges.filter(edge => edge.source !== id && edge.target !== id);
  nodePreviews.delete(id);
  if(selectedNodeId === id) selectedNodeId = null;
  if(previewActionNodeId === id) previewActionNodeId = null;
  if(colorPaletteNodeId === id) colorPaletteNodeId = null;
  if(lightboxNodeId === id) closeImageLightbox();
  render();
  commitActiveWorkflowChange();
  toast("已删除节点", id, true);
}
function deleteSelectedNode(){ if(selectedNodeId) deleteNode(selectedNodeId); }

function buildWorkflow(){
  return {
    version:"2.1",
    nodes:nodes.map(node => ({
      id:node.id,
      type:node.type,
      position:node.position,
      params:{ ...(node.params || {}) },
      collapsed:Boolean(node.collapsed),
      color:node.color || DEFAULT_NODE_COLOR,
    })),
    edges:edges.map(edge => ({ ...edge })),
  };
}

async function runWorkflow(){
  const workflow = buildWorkflow();
  setStatus("运行中...");
  document.getElementById("taskCount").textContent = "1";
  if(previewCollapsed) togglePreviewPanel(false);
  previewPanel.innerHTML = '<div class="empty-preview">正在运行 OpenCV 流程...</div>';
  try{
    const data = await VisionApi.executeWorkflow(workflow);
    renderPreviews(data.previews || [], data.batch || null);
    if(data.mode === "batch" && data.batch){
      const batch = data.batch;
      setStatus(`批量运行完成：共 ${batch.total} 张，成功 ${batch.succeeded} 张，失败 ${batch.failed} 张。结果目录：${batch.output_dir}`);
      toast("批量处理完成", `成功 ${batch.succeeded} / ${batch.total}，失败 ${batch.failed}`, batch.failed === 0);
    }else{
      setStatus(`运行成功。执行顺序：${(data.order || []).join(" → ")}`);
      toast("运行成功", `已生成 ${(data.previews || []).length} 个节点结果`, true);
    }
  }catch(error){
    const message = error && error.message ? error.message : String(error);
    setStatus(`运行失败：${message}`);
    previewPanel.innerHTML = `<div class="empty-preview">运行失败：${escapeHtml(message)}</div>`;
    toast("运行失败", message);
  }finally{
    document.getElementById("taskCount").textContent = "0";
  }
}

function togglePreviewPanel(force){
  previewCollapsed = typeof force === "boolean" ? force : !previewCollapsed;
  previewWrap.classList.toggle("collapsed", previewCollapsed);
  previewToggleText.textContent = previewCollapsed ? "展开" : "折叠";
  if(!suppressDocumentSync) persistActiveWorkflowView();
}

function renderPreviews(previews, batchSummary = null){
  nodePreviews.clear();
  previews.forEach(item => nodePreviews.set(item.node_id, item));
  previewActionNodeId = null;
  renderNodes();
  updateMinimap();

  previewPanel.innerHTML = "";
  if(batchSummary) renderBatchSummary(batchSummary);
  if(!previews.length){
    if(!batchSummary) previewPanel.innerHTML = '<div class="empty-preview">没有生成预览结果</div>';
    return;
  }
  previews.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "preview-card";
    const title = `${index + 1}. ${item.node_id} · ${item.label}`;
    card.innerHTML = `<div class="preview-meta"><b title="${escapeHtml(title)}">${escapeHtml(title)}</b><span class="tag">${escapeHtml(item.type || "")}</span></div><img src="${item.image || ""}" alt="${escapeHtml(title)}" title="点击查看原图" />`;
    card.querySelector("img").addEventListener("click", () => openImageLightbox(item.node_id));
    previewPanel.appendChild(card);
  });
  if(!suppressDocumentSync) captureActiveWorkflowDocument(false);
}

function renderBatchSummary(batch){
  const card = document.createElement("div");
  card.className = "batch-summary";
  const failedRows = (batch.rows || []).filter(row => row.status === "error").slice(0, 5);
  const csvLine = batch.csv_path
    ? `<div class="batch-summary-path"><strong>CSV：</strong>${escapeHtml(batch.csv_path)}</div>`
    : "";
  const errors = failedRows.length
    ? `<div class="batch-summary-errors"><strong>前 ${failedRows.length} 个失败：</strong><br>${failedRows.map(row => `${escapeHtml(row.source_name || row.source_path)}：${escapeHtml(row.error || "未知错误")}`).join("<br>")}</div>`
    : "";
  card.innerHTML = `<div class="batch-summary-title"><span>批量处理汇总</span><span class="tag">BATCH</span></div>
    <div class="batch-summary-grid">
      <div class="batch-summary-stat"><b>${Number(batch.total || 0)}</b><span>总图片</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.succeeded || 0)}</b><span>成功</span></div>
      <div class="batch-summary-stat"><b>${Number(batch.failed || 0)}</b><span>失败</span></div>
    </div>
    <div class="batch-summary-path"><strong>结果目录：</strong>${escapeHtml(batch.output_dir || "")}</div>
    ${csvLine}${errors}`;
  previewPanel.appendChild(card);
}

function downloadNodePreview(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("下载失败", "该节点还没有可下载的结果图");
    return;
  }
  const anchor = document.createElement("a");
  anchor.href = preview.image;
  anchor.download = `${safeFilename(nodeId)}_${safeFilename(preview.label || preview.type || "result")}.png`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  toast("开始下载", anchor.download, true);
}

function openImageLightbox(nodeId){
  const preview = nodePreviews.get(nodeId);
  if(!preview || !preview.image){
    toast("无法放大", "该节点还没有结果图");
    return;
  }
  lightboxNodeId = nodeId;
  const lightbox = document.getElementById("imageLightbox");
  const image = document.getElementById("lightboxImage");
  document.getElementById("lightboxTitle").textContent = `${nodeId} · ${preview.label || preview.type || "节点结果"}`;
  document.getElementById("lightboxMeta").textContent = "原始分辨率 · 可滚动查看";
  image.src = preview.image;
  image.alt = `${preview.label || nodeId} 的原图`;
  document.getElementById("lightboxDownload").onclick = event => {
    event.stopPropagation();
    downloadNodePreview(nodeId);
  };
  document.getElementById("lightboxRestore").onclick = event => {
    event.stopPropagation();
    closeImageLightbox();
  };
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
  document.body.classList.add("lightbox-open");
}
function closeImageLightbox(){
  const lightbox = document.getElementById("imageLightbox");
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
  document.getElementById("lightboxImage").removeAttribute("src");
  lightboxNodeId = null;
  document.body.classList.remove("lightbox-open");
}

async function exportAlgorithmScript(){
  if(!nodes.length){ toast("导出失败", "请先编排工作流"); return; }
  setStatus("正在生成独立算法脚本...");
  try{
    const result = await VisionApi.exportScript(buildWorkflow());
    const url = URL.createObjectURL(result.blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = result.filename || "vision_algorithm.py";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setStatus("独立算法脚本已导出");
    toast("脚本已导出", anchor.download, true);
  }catch(error){
    setStatus(`脚本导出失败：${error.message}`);
    toast("脚本导出失败", error.message);
  }
}

function saveWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  captureActiveWorkflowDocument(false);
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  storageSet("vision_python_mvp_workflow_v3", JSON.stringify(documentInfo.workflow, null, 2));
  renderWorkflowTabs();
  persistWorkspace();
  toast("工作流已保存", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已保存（Ctrl+S）`);
}
function loadWorkflowLocal(){
  const documentInfo = getActiveWorkflowDocument();
  if(!documentInfo) return;
  let workflow = null;
  if(documentInfo.savedSnapshot){
    try{ workflow = JSON.parse(documentInfo.savedSnapshot); }catch(error){ console.warn(error); }
  }
  if(!workflow){
    const raw = storageGet("vision_python_mvp_workflow_v3") || storageGet("vision_python_mvp_workflow_v2");
    if(raw){
      try{ workflow = JSON.parse(raw); }catch(error){ toast("加载失败", error.message || String(error)); return; }
    }
  }
  if(!workflow){ toast("加载失败", "当前工作流还没有保存版本"); return; }
  suppressDocumentSync = true;
  try{ applyWorkflow(workflow, { silent:true }); }finally{ suppressDocumentSync = false; }
  documentInfo.workflow = buildWorkflow();
  documentInfo.savedSnapshot = workflowSignature(documentInfo.workflow);
  documentInfo.name = documentInfo.savedName || documentInfo.name;
  documentInfo.savedName = documentInfo.name;
  documentInfo.dirty = false;
  documentInfo.runtimePreviews = [];
  renderWorkflowTabs();
  persistWorkspace();
  toast("已恢复保存版本", documentInfo.name, true);
  setStatus(`${documentInfo.name} 已恢复到最近保存状态`);
}
function downloadWorkflowJson(){
  const documentInfo = getActiveWorkflowDocument();
  const blob = new Blob([JSON.stringify(buildWorkflow(), null, 2)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${safeFilename(documentInfo?.name || "vision_workflow")}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}
function resetView(){ pan = { x:-260, y:-120 }; zoom = .82; applyTransform(); persistActiveWorkflowView(); setStatus("已重置画布视图"); }

function applyWorkflow(workflow, options = {}){
  nodePreviews.clear();
  previewActionNodeId = null;
  colorPaletteNodeId = null;
  closeImageLightbox();
  nodes = (workflow.nodes || []).map(rawNode => {
    const normalized = normalizeNodeType(rawNode.type, rawNode.params || {});
    if(!OPERATOR_META[normalized.type]) return null;
    return {
      id:rawNode.id,
      type:normalized.type,
      position:rawNode.position || { x:100, y:100 },
      params:{ ...defaultParams(normalized.type), ...normalized.params },
      collapsed:Boolean(rawNode.collapsed),
      color:safeColor(rawNode.color || DEFAULT_NODE_COLOR),
    };
  }).filter(Boolean);
  edges = (workflow.edges || []).filter(edge => nodes.some(node => node.id === edge.source) && nodes.some(node => node.id === edge.target));
  const maxSequence = nodes.reduce((maxValue, node) => Math.max(maxValue, Number(String(node.id).replace(/^n/, "")) || 0), 0);
  nodeSeq = maxSequence + 1;
  selectedNodeId = nodes[0]?.id || null;
  selectedEdgeId = null;
  previewPanel.innerHTML = '<div class="empty-preview">运行后显示每步处理结果</div>';
  render();
  if(!options.silent) setStatus("工作流已加载；旧版 Gray/BGR2RGB 节点已自动迁移为颜色转换节点");
}

function createDemoWorkflow(){
  applyWorkflow(demoWorkflowDefinition(), { silent:true });
  pan = { x:-260, y:-120 };
  zoom = .82;
  applyTransform();
  commitActiveWorkflowChange();
  setStatus("示例流程已生成。请在读取图像节点内填写服务器图片路径，然后运行。");
  toast("示例流程已生成", "请先填写 ReadImage 的图片路径", true);
}

function clearWorkflow(){
  applyWorkflow(emptyWorkflow(), { silent:true });
  commitActiveWorkflowChange();
  setStatus("流程已清空");
}

function toast(title, text, ok){
  const element = document.getElementById("toast");
  document.getElementById("toastTitle").textContent = title;
  document.getElementById("toastText").textContent = text || "";
  element.className = `toast show${ok ? " ok" : ""}`;
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => element.className = "toast", 3200);
}
function setStatus(text){ statusEl.textContent = text; }
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, character => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[character]);
}
function safeFilename(value){ return String(value).replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "") || "result"; }
function safeColor(value){ return /^#[0-9a-fA-F]{6}$/.test(String(value)) ? String(value) : DEFAULT_NODE_COLOR; }

function updateMinimap(){
  const mini = document.getElementById("miniNodes");
  mini.innerHTML = "";
  const scale = .035;
  nodes.forEach(node => {
    const marker = document.createElement("div");
    marker.className = "mini-node";
    marker.style.left = `${node.position.x * scale + 14}px`;
    marker.style.top = `${node.position.y * scale + 22}px`;
    marker.style.width = `${NODE_WIDTH * scale}px`;
    marker.style.height = `${Math.max(20, nodeHeight(node) * scale)}px`;
    marker.style.background = safeColor(node.color || DEFAULT_NODE_COLOR);
    mini.appendChild(marker);
  });
  const rect = viewport.getBoundingClientRect();
  const view = document.getElementById("miniView");
  view.style.left = `${(0 - pan.x) / zoom * scale + 14}px`;
  view.style.top = `${(0 - pan.y) / zoom * scale + 22}px`;
  view.style.width = `${rect.width / zoom * scale}px`;
  view.style.height = `${rect.height / zoom * scale}px`;
}

document.addEventListener("keydown", event => {
  if((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s"){
    event.preventDefault();
    saveWorkflowLocal();
    return;
  }
  if(event.key === "Escape"){
    if(lightboxNodeId){ closeImageLightbox(); return; }
    connectingSourceId = null;
    clearTempEdge();
    previewActionNodeId = null;
    colorPaletteNodeId = null;
    renderNodes();
    setStatus("已取消当前操作");
  }
  if((event.key === "Delete" || event.key === "Backspace") && selectedEdgeId && !event.target.matches("input,textarea,select")){
    event.preventDefault();
    deleteSelectedEdge();
  }
});
window.addEventListener("resize", updateMinimap);
document.getElementById("nodeLibraryToggle").addEventListener("click", toggleNodeLibrary);
document.getElementById("newWorkflowButton").addEventListener("click", newWorkflow);
document.getElementById("exportScriptButton").addEventListener("click", exportAlgorithmScript);
document.getElementById("workflowInput").addEventListener("change", async event => {
  const file = event.target.files[0];
  if(!file) return;
  try{
    applyWorkflow(JSON.parse(await file.text()), { silent:true });
    const documentInfo = getActiveWorkflowDocument();
    if(documentInfo){
      documentInfo.name = file.name.replace(/\.json$/i, "") || documentInfo.name;
    }
    commitActiveWorkflowChange();
    toast("JSON 流程已导入", file.name, true);
    setStatus(`已导入到当前工作流：${documentInfo?.name || file.name}`);
  }catch(error){
    toast("导入失败", error.message || String(error));
  }finally{
    event.target.value = "";
  }
});
setNodeLibraryVisible(true);
initOperators();
