# 工业视觉流程编辑器

这是一个基于 FastAPI、OpenCV 和原生 Web 技术实现的节点式工业视觉流程编辑器。前端、API 通信层、后端工作流调度、OpenCV 算法、批量测试以及独立脚本导出均已分层。

## 启动

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS / Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

浏览器打开 `http://127.0.0.1:8000`。

## 单图流程

单图流程以 `ReadImage` 开始，通过节点内的 `image_path` 参数读取运行 FastAPI 后端的计算机上的图片：

```text
相对路径：samples/part.png
绝对路径：D:\images\part.png
```

相对路径以项目根目录为基准。

## 批量测试

节点库新增“批量处理”分组。可直接导入示例：`examples/batch_workflow.json`。


```text
批量读取图片 → 图像算法/测量算子 → 保存批量结果
```

### 批量读取图片

- `folder_path`：服务器上的图片目录；
- `recursive`：是否读取子目录；
- `extensions`：扩展名列表，例如 `.png,.jpg`；
- `max_images`：最大处理数量，`0` 表示不限制；
- `continue_on_error`：单张失败后是否继续。

### 保存批量结果

- 用户可填写结果保存目录；
- 可选择是否保存结果图；
- 可选择 PNG、JPEG、WebP 或沿用原图格式；
- 可保留输入目录的子目录结构；
- 可生成 UTF-8 BOM CSV，Excel 直接打开中文不会乱码。

CSV 基础列包括：

```text
source_path, source_name, relative_path, output_path, status, error
```

测量算子的 `metrics` 会自动追加为动态列。一个图片可以包含多个结果，一个工作流也可以串联多个测量算子。

批量运行结束后，右侧会显示总数量、成功数、失败数、结果目录和 CSV 路径；节点预览显示最后一张成功图片的完整处理效果，避免一次返回大量 Base64 图片占用内存。

## 自定义算子

项目会自动扫描：

```text
backend/custom_operators/*.py
```

复制 `_template.py`、修改后重启服务，新算子就会自动出现在左侧“自定义算子”分组，不需要修改前端或注册表。

完整说明见：[docs/CUSTOM_OPERATORS.md](docs/CUSTOM_OPERATORS.md)。项目自带 `MeanBrightness` 示例，它会输出平均亮度和标准差，并自动进入批量 CSV。

## 节点缩略图

节点底部的预览使用图片自身宽高并限制最大尺寸：

```css
width: auto;
height: auto;
max-width: 100%;
max-height: 100%;
object-fit: contain;
```

因此缩略图会完整显示，不裁切，也不会为了填满预览框而拉伸。点击缩略图后可以下载或查看原始分辨率图片。

## 颜色转换

“灰度化”和“BGR 转 RGB”统一为 `ColorConvert` 节点，通过 `mode` 参数选择 `GRAY` 或 `RGB`。导入旧工作流时，`Gray` 和 `BGR2RGB` 会自动迁移。

## 导出为独立算法脚本

点击左侧“导出脚本”，当前流程会通过 AST 编译为普通、顺序执行的 OpenCV 代码，并下载为 `vision_algorithm.py`。

生成脚本中不包含节点、连线、工作流 JSON、拓扑排序、FastAPI 或项目模块引用。批量输入节点在导出时被视为普通图像输入，批量保存节点被视为算法终点，因此生成文件仍是可复用的单图算法函数。

```bash
pip install opencv-python numpy
python vision_algorithm.py --input input.png --output result.png
```

## 多工作流标签

- `＋` 新建空白工作流；
- 点击标签切换；
- 双击标签名称重命名；
- 白点表示已保存，橙点表示有未保存修改；
- `Ctrl+S` / `Command+S` 保存当前工作流；
- 刷新后恢复多个标签及草稿。

## 目录结构

```text
industrial_vision_refactored/
├── backend/
│   ├── api/                    # FastAPI 路由
│   ├── algorithms/             # 内置算子、元数据、插件加载器
│   ├── custom_operators/       # 用户自定义算子与模板
│   ├── models/                 # Pydantic 工作流模型
│   └── services/               # 单图/批量执行、图片路径、AST 导出
├── docs/
│   └── CUSTOM_OPERATORS.md
├── frontend/
│   ├── index.html
│   └── assets/
│       ├── css/styles.css
│       └── js/
│           ├── api.js
│           └── app.js
├── tests/
├── requirements.txt
└── run.py
```

## API

- `GET /api/operators`
- `POST /api/run`：自动识别单图流程或批量流程
- `POST /api/export-script`
- `POST /api/upload`：仅保留旧版兼容
